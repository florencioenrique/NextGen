document.getElementById('add-symptom').addEventListener('click', function() {
    const symptomsContainer = document.getElementById('symptoms_container');
    const newSymptomField = document.createElement('div');
    newSymptomField.className = 'mb-3 symptoms_field';

    const newInputField = document.createElement('input');
    newInputField.type = 'text';
    newInputField.className = 'form-control mt-2';
    newInputField.placeholder = 'Input symptoms associated with the disease';

    newSymptomField.appendChild(newInputField);
    symptomsContainer.appendChild(newSymptomField);
});

document.getElementById('diseaseForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const symptomsFields = document.querySelectorAll('.symptoms_field input');
    const symptomsArray = Array.from(symptomsFields).map(input => input.value.trim()).filter(value => value !== "");
    const symptomsStr = symptomsArray.join(';');

    const formData = new FormData(this); 
    formData.set('symptoms', symptomsStr); 

    fetch(this.action, {
                method: this.method,
                body: formData
            }).then(response => {
                if (response.ok) {
                    window.location.href = '/experts_dashboard';
                }
            }).catch(error => console.error('Error:', error));
        });
        
// document.addEventListener("DOMContentLoaded", function() {
//     const sidebar = document.getElementById("sidebar");
//     const content = document.querySelector(".content");
//     const sidebarToggle = document.getElementById("sidebarToggle");
//     const sidebarClose = document.getElementById("sidebarClose");
//     const navLinks = document.querySelectorAll(".nav-link");
//     const contentSections = document.querySelectorAll(".content-section");

//     function toggleSidebar() {
//         if (window.innerWidth <= 768) {
//             sidebar.classList.toggle("show");
//             } else {
//                 sidebar.classList.toggle("collapsed");
//                 content.classList.toggle("expanded");
//             }
//         }

//         sidebarToggle.addEventListener("click", toggleSidebar);
//         sidebarClose.addEventListener("click", () => sidebar.classList.remove("show"));

//          navLinks.forEach(link => {
//             link.addEventListener("click", function(e) {
//                 e.preventDefault();
//                 const sectionId = this.getAttribute("data-section");
                    
//                 navLinks.forEach(l => l.classList.remove("active"));
//                 this.classList.add("active");

//                 contentSections.forEach(section => {
//                     section.classList.remove("active");
//                 });
//                 document.getElementById(sectionId).classList.add("active");

//                 if (window.innerWidth <= 768) {
//                     sidebar.classList.remove("show");
//                 }
//             });
//         });

//         window.addEventListener('resize', function () {
//             if (window.innerWidth > 768) {
//                 sidebar.classList.remove("show");
//                 content.classList.remove("expanded");
//             } else {
//                 sidebar.classList.remove("collapsed");
//                 content.classList.remove("expanded");
//             }
//         });
//     });