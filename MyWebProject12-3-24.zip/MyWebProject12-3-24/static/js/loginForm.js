const togglePassword = document.querySelector('#togglePassword');
const password = document.querySelector('#password');
const toggleIcon = document.querySelector('#toggleIcon');

const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const loginButton = document.getElementById('loginButton');

togglePassword.addEventListener('click', function () {
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    toggleIcon.classList.toggle('bi-eye');
    toggleIcon.classList.toggle('bi-eye-slash');
});

function setFormAction(userType) {
    const form = document.getElementById('loginForm');
    if (userType === 'consultant') {
        form.action = "{{ url_for('login') }}"; // Consultant login URL
    } else if (userType === 'expert') {
        form.action = "{{ url_for('expert_login') }}"; // Expert login URL
    }
    usernameInput.disabled = false;
    passwordInput.disabled = false;
    loginButton.disabled = false;
}

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(this); 
    const actionUrl = this.getAttribute('action'); 

    fetch(actionUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (actionUrl === "{{ url_for('login') }}") { // Match the action set
                window.location.href = '/consultant'; 
            } else if (actionUrl === "{{ url_for('expert_login') }}") { // Match the action set
                window.location.href = '/experts_dashboard'; 
            }
        } else {
            document.getElementById('errorMessage').textContent = data.message;
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});