from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash
from werkzeug.utils import secure_filename
from flask_mail import Mail, Message
import random
import string
import numpy as np
import pandas as pd
import csv
import os
import mysql.connector
import sqlite3
import uuid


vcId = str(uuid.uuid4())

app = Flask(__name__, template_folder='templates')
app.secret_key = 'your_secret_key'

app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'florencioenrique69@gmail.com'
app.config['MAIL_PASSWORD'] = 'owaw sgni koox vvky'  # Use app password or secure method for real applications
app.config['MAIL_DEFAULT_SENDER'] = 'NextGen Health Diagnostic Web'

mail = Mail(app)


app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# Database connection
def get_db_connection():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='nextgen'
    )
    return connection
    

# Load data from CSV files
data = pd.read_csv('datasets/disease.csv')
data['Symptoms'] = data['Symptoms'].apply(lambda x: x.split(';'))

descriptions = {}
with open('datasets/disease_descriptions.csv', mode='r', newline='') as file:
    reader = csv.DictReader(file)
    for row in reader:
        descriptions[row['Disease']] = row['Description']

doctors = {}
with open('datasets/doctors.csv', mode='r', newline='') as file:
    reader = csv.DictReader(file)
    for row in reader:
        disease = row['Disease']
        doctor_type = row['Doctor_Type']
        if disease not in doctors:
            doctors[disease] = []
        doctors[disease].append(doctor_type)

# def load_symptoms_by_anatomy():
#     symptoms_data = {}
#     with open('datasets/symptoms_anatomy.csv', 'r') as file:
#         reader = csv.DictReader(file)
#         for row in reader:
#             anatomy = row['Anatomy']
#             symptom = row['Symptom']
            
#             if anatomy not in symptoms_data:
#                 symptoms_data[anatomy] = []
            
#             symptoms_data[anatomy].append(symptom)
#     return symptoms_data

def fetch_matched_doctors(disease):
    matched_doctors = []
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT first_name, expertise FROM doctors WHERE expertise = %s", (disease,))
    doctors_data = cursor.fetchall()
    
    for doctor in doctors_data:
        matched_doctors.append(doctor['first_name']) 

    cursor.close()
    conn.close()
    
    return matched_doctors

for disease in doctors.keys():
    matched_doctors = fetch_matched_doctors(disease)
    if matched_doctors:
        doctors[disease] = [{
            'doctor_type': doc['doctor_type'],
            'doctor_name': doc['doctor_na me'],
            'matched_doctors': matched_doctors
        } for doc in doctors[disease]]

@app.route('/add_disease', methods=['POST'])
def add_disease():
    disease = request.form['disease_name']
    symptoms = request.form['symptoms']

    if disease and symptoms:
        symptoms_list = [symptom.strip() for symptom in symptoms.split(';')]

        disease_exists = False
        existing_symptoms = []

        with open('datasets/disease.csv', mode='r', newline='') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0].strip() == disease:
                    disease_exists = True
                    existing_symptoms = row[1].split(';')
                    break

        if disease_exists:
            existing_symptoms_set = set(existing_symptoms)
            for symptom in symptoms_list:
                existing_symptoms_set.add(symptom)

            symptoms_str = ';'.join(existing_symptoms_set)
            updated_rows = []
            with open('datasets/disease.csv', mode='r', newline='') as file:
                reader = csv.reader(file)
                for row in reader:
                    if row[0].strip() == disease:
                        updated_rows.append([disease, symptoms_str]) 
                    else:
                        updated_rows.append(row)

            with open('datasets/disease.csv', mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerows(updated_rows)

        else:
            symptoms_str = ';'.join(symptoms_list)
            with open('datasets/disease.csv', mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([disease, symptoms_str]) 

    return redirect(url_for('experts_dashboard'))

# Prepare symptom and disease lists
symptoms = list(set([symptom for sublist in data['Symptoms'] for symptom in sublist]))
diseases = data['Disease'].unique()

X = np.array([[1 if symptom in symptoms_list else 0 for symptom in symptoms] for symptoms_list in data['Symptoms']])
y = np.array([[1 if d == disease else 0 for d in diseases] for disease in data['Disease']])

class SimpleNN:
    def __init__(self, input_size, hidden_size, output_size):
        self.W1 = np.random.rand(input_size, hidden_size)
        self.W2 = np.random.rand(hidden_size, output_size)

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_derivative(self, x):
        return x * (1 - x)

    def feedforward(self, X):
        self.hidden = self.sigmoid(np.dot(X, self.W1))
        self.output = self.sigmoid(np.dot(self.hidden, self.W2))
        return self.output

    def backpropagation(self, X, y, learning_rate):
        output_error = y - self.output
        output_delta = output_error * self.sigmoid_derivative(self.output)

        hidden_error = output_delta.dot(self.W2.T)
        hidden_delta = hidden_error * self.sigmoid_derivative(self.hidden)

        self.W2 += self.hidden.T.dot(output_delta) * learning_rate
        self.W1 += X.T.dot(hidden_delta) * learning_rate

    def train(self, X, y, epochs, learning_rate):
        for _ in range(epochs):
            self.feedforward(X)
            self.backpropagation(X, y, learning_rate)

nn = SimpleNN(len(symptoms), 5, len(diseases))
nn.train(X, y, epochs=10000, learning_rate=0.1)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/userReg')
def user_registration():
    return render_template('userReg.html')

@app.route('/about')
def view_about():
    return render_template('about.html')

@app.route('/vc/<vcId>')
def vc(vcId):

    if 'user_fname' not in session or 'user_lname' not in session:
        return redirect(url_for('home'))
    
    patient_fname = session['user_fname']
    patient_lname = session['user_lname']

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute('''
        SELECT * FROM appointment WHERE vcId = %s
    ''', (vcId,))

    appointment = cursor.fetchone()
    
    cursor.close()
    conn.close()

    if appointment:
        return render_template('vc.html', appointment=appointment, patient_fname=patient_fname, patient_lname=patient_lname)
    else:
        return "Appointment not found", 404

@app.route('/join/<vcId>')
def join(vcId):
    # Fetch additional details if needed, like appointment or user info, based on vcId
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT * FROM appointment WHERE vcId = %s", (vcId,))
    appointment = cursor.fetchone()

    cursor.close()
    conn.close()

    if not appointment:
        return "Appointment not found.", 404

    return render_template('vc.html', vcId=vcId, appointment=appointment)


@app.route('/contact')
def view_contact():
    return render_template('contact.html')

@app.route('/registration_form', methods=['GET', 'POST'])
def registration_form():
    if request.method == 'POST':
        user_type = request.form['userType']
        first_name = request.form['firstName']
        last_name = request.form['lastName']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        zip_code = request.form['zipCode']
        username = request.form['username']
        password = request.form['password']
        status = request.form['status']
        date = request.form['dateCreated']

        medical_license = request.form.get('medicalLicense', '')
        specialization = request.form.get('specialization', '')

        # Handle file upload
        certificate_path = None
        if 'certificate' in request.files:
            certificate_file = request.files['certificate']
            if certificate_file.filename != '':
                filename = secure_filename(certificate_file.filename)
                certificate_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                certificate_file.save(certificate_path)

        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            if user_type == 'consultant':
                cursor.execute('''
                    INSERT INTO consultanttable (first_name, last_name, email, phone, address, zip_code, username, password, certificate_path)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                ''', (first_name, last_name, email, phone, address, zip_code, username, password, certificate_path))
            elif user_type == 'doctor':
                cursor.execute('''
                    INSERT INTO doctors (first_name, last_name, email, phone, address, zip_code, username, password, 
                    medLicense, expertise, date, status, certificate_path)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ''', (first_name, last_name, email, phone, address, zip_code, username, password,
                    medical_license, specialization, date, status, certificate_path))

            conn.commit()
            flash('Registration successful!', 'success')
            return redirect(url_for('success_page'))  # Redirect to a success page after registration

        except Exception as e:
            print(f"Error occurred: {e}")
            flash('Registration failed. Please try again.', 'danger')
            return redirect(url_for('registration_form'))

        finally:
            cursor.close()
            conn.close()

    return render_template('userReg.html')

@app.route('/submit_appointment', methods=['POST'])
def submit_appointment():
    if 'user_id' not in session:
        return redirect(url_for('home'))
    
    patient_id = session['user_id']
    patient_name = session['user_fname']
    
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''
        SELECT email FROM consultanttable WHERE id = %s AND first_name = %s
    ''', (patient_id, patient_name))

    result = cursor.fetchone()
    
    if result:
        patient_email = result[0]
    else:
        patient_email = None

    aptype = request.form['aptype']
    date = request.form['date']
    status = 'Pending'
    doctorId = request.form['doctorId']

    vcId = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

    cursor.execute('''
        INSERT INTO appointment (type, appointment_date, status, patientId, doctorId, name, email, vcId)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    ''', (aptype, date, status, patient_id, doctorId, patient_name, patient_email, vcId))

    # Commit the transaction and close the cursor and connection
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(url_for('consultant'))



@app.route('/success_page')
def success_page():
    return render_template('userReg.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    symptoms_input = [symptom.capitalize() for symptom in data['symptoms']]

    not_found_symptoms = [symptom for symptom in symptoms_input if symptom not in symptoms]
    if not_found_symptoms:
        return jsonify({'error': f"Symptoms not found: {', '.join(not_found_symptoms)}"}), 400

    sample_input = np.array([[1 if symptom in symptoms_input else 0 for symptom in symptoms]])
    output = nn.feedforward(sample_input)

    predictions = {disease: output[0][i] for i, disease in enumerate(diseases)}
    sorted_predictions = sorted(predictions.items(), key=lambda item: item[1], reverse=True)

    top_predictions = [
        {
            'disease': sorted_predictions[i][0],
            'probability': sorted_predictions[i][1] * 100,
            'description': descriptions.get(sorted_predictions[i][0], ''),
            'doctors': [],
            'expertise': ''
        } 
        for i in range(min(5, len(sorted_predictions)))
    ]

    most_likely = top_predictions[0] if top_predictions else {}

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Match doctors based on disease
    if most_likely:
        disease = most_likely['disease']
        doctor_types = doctors.get(disease, [])

        for doctor_type in doctor_types:
            cursor.execute("SELECT id, first_name, last_name, address, expertise FROM doctors WHERE expertise = %s", (doctor_type,))
            matched_doctors = cursor.fetchall()
            for doc in matched_doctors:
                most_likely['doctors'].append({
                    'id': doc['id'],
                    'name': f"{doc['first_name']} {doc['last_name']}",
                    'address': doc['address']
                })
                most_likely['expertise'] = doc['expertise']

    for i in range(len(top_predictions)):
        disease = top_predictions[i]['disease']
        doctor_types = doctors.get(disease, [])
        expertise_set = set()
        doctors_list = []

        for doctor_type in doctor_types:
            cursor.execute("SELECT id, first_name, last_name, address, expertise FROM doctors WHERE expertise = %s", (doctor_type,))
            matched_doctors = cursor.fetchall()
            for doc in matched_doctors:
                expertise_set.add(doc['expertise'])
                doctors_list.append({
                    'id': doc['id'],
                    'name': f"{doc['first_name']} {doc['last_name']}",
                    'address': doc['address']
                })

        top_predictions[i]['expertise'] = ', '.join(expertise_set)
        top_predictions[i]['doctors'] = doctors_list

    cursor.close()
    conn.close()

    return jsonify({
        'most_likely': most_likely,
        'top_predictions': top_predictions
    })


@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)  # Using dictionary cursor
    cursor.execute("SELECT id, first_name, last_name FROM consultanttable WHERE username = %s AND password = %s", (username, password))
    user = cursor.fetchone()
    connection.close()

    if user:
        # Store user id, first name, and last name in session
        session['user_id'] = user['id']
        session['user_fname'] = user['first_name']
        session['user_lname'] = user['last_name']

        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': 'Incorrect username or password!'})
 
@app.route('/expert_login', methods=['POST'])
def expert_login():
    username = request.form['username']
    password = request.form['password']

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM doctors WHERE username = %s AND password = %s", (username, password))
    expert = cursor.fetchone()
    connection.close()

    if expert and expert.get('status') == 'VERIFIED':
        session['expert_id'] = expert['id']
        session['expert_name'] = f"{expert['first_name']} {expert['last_name']}"
        session['expert_username'] = expert['username']
        print("Expert Name in Session:", session['expert_name'])  # Debug statement
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': 'Incorrect username or password!'})

@app.route('/consultant')
def consultant():
    # data = load_symptoms_by_anatomy()

    if 'user_id' not in session:
        return redirect(url_for('home'))
      
    user_fname = session.get('user_fname', "User")
    user_id = session['user_id']
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT DISTINCT expertise FROM doctors")
    expertise_list = [row['expertise'] for row in cursor.fetchall()]

    cursor.execute("SELECT * FROM doctors")
    doctors = cursor.fetchall()

    cursor.execute("""
        SELECT doctors.first_name, doctors.last_name, doctors.expertise AS type, doctors.address,
               appointment.appointment_date, appointment.vcId
        FROM doctors
        JOIN appointment ON doctors.id = appointment.doctorId
        WHERE appointment.patientId = %s AND appointment.status = 'Accepted'
    """, (session['user_id'],))
    
    doctors = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('consultant.html', symptoms=symptoms, expertise_list=expertise_list, doctors=doctors, user_fname=user_fname, data=data)


# Expert dashboard route
@app.route('/experts_dashboard')
def experts_dashboard():
    if 'expert_id' not in session:
        return redirect(url_for('home'))

    # Get the expert's full name
    expert_name = session.get('expert_name', '')  # This should contain "FirstName LastName"

    # Fetch additional data
    expert_id = session['expert_id']
    patient_fname = session.get('user_fname', '')
    patient_lname = session.get('user_lname', '')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch consultants
    cursor.execute("SELECT first_name, last_name, email FROM consultanttable")
    consultants = cursor.fetchall()

    # Fetch pending appointments
    cursor.execute('''
        SELECT appointment.id, appointment.type, appointment.appointment_date, appointment.status,
               consultanttable.first_name, consultanttable.last_name, consultanttable.email
        FROM appointment
        JOIN consultanttable ON appointment.patientId = consultanttable.id
        WHERE appointment.doctorId = %s
        AND consultanttable.first_name = %s
        AND consultanttable.last_name = %s
        AND appointment.status = 'Pending'
    ''', (expert_id, patient_fname, patient_lname))
    appointments = cursor.fetchall()

    # Fetch accepted appointments
    cursor.execute('''
        SELECT appointment.id, appointment.type, appointment.appointment_date, appointment.status,
               consultanttable.first_name, consultanttable.last_name, consultanttable.email, appointment.vcId
        FROM appointment
        JOIN consultanttable ON appointment.patientId = consultanttable.id
        WHERE appointment.doctorId = %s
        AND consultanttable.first_name = %s
        AND consultanttable.last_name = %s
        AND appointment.status = 'Accepted'
    ''', (expert_id, patient_fname, patient_lname))
    accepted_appointments = cursor.fetchall()

    cursor.close()
    conn.close()

    # Pass expert_name and data to the template
    return render_template(
        'experts.html',
        expert_name=expert_name,
        consultants=consultants,
        appointments=appointments,
        accepted_appointments=accepted_appointments,
        symptoms=symptoms,
    )


@app.route('/accept/<int:appointment_id>', methods=['POST'])
def accept_appointment(appointment_id):
    # Get the email, first name, and appointment date from the request form or query params
    email = request.form.get('email') or request.args.get('email')
    first_name = request.form.get('first_name') or request.args.get('first_name')
    appointment_date = request.form.get('appointment_date') or request.args.get('appointment_date')

    if email and first_name and appointment_date:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get appointment details to use for the email
        cursor.execute("SELECT email, name, appointment_date FROM appointment WHERE id = %s", (appointment_id,))
        appointment = cursor.fetchone()

        if appointment:
            # Update the status to "Accepted"
            cursor.execute("UPDATE appointment SET status = 'Accepted' WHERE id = %s", (appointment_id,))
            conn.commit()
            conn.close()

            # Send the acceptance email
            send_acceptance_email(email, first_name, appointment_date)

            return redirect(url_for('experts_dashboard'))
        else:
            conn.close()
            return "Appointment not found."

    return "Required information is missing."

# Example function to send an acceptance email
def send_acceptance_email(email, first_name, appointment_date):
    subject = "Appointment Accepted"
    body = f"Dear {first_name},\n\nYour appointment on {appointment_date} has been accepted.\n\nBest regards,\nNextGen Health Diagnostic Web"
    
    msg = Message(subject=subject, recipients=[email], body=body)
    
    try:
        mail.send(msg)
        print("Email sent successfully!")
    except Exception as e:
        print(f"Failed to send email: {e}")

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))


if __name__ == '__main__':
    app.secret_key = 'nextGenHD 2024'
    app.run(host='0.0.0.0', port=5000)  
    app.run(debug=True)