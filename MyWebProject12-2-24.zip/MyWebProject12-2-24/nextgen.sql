-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2024 at 05:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nextgen`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_account`
--

INSERT INTO `admin_account` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorId` int(11) NOT NULL,
  `patientId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `appointment_date` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `vcId` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorId`, `patientId`, `name`, `email`, `type`, `appointment_date`, `status`, `vcId`) VALUES
(1, 1, 0, '', '', 'Consultation', '2024-11-09', 'Pending', ''),
(2, 0, 0, '', '', 'Consultation', '2024-11-09', 'Pending', ''),
(3, 0, 0, '', '', 'Consultation', '2024-11-09', 'Pending', ''),
(4, 0, 1, '', '', 'Consultation', '2024-11-09', 'Pending', ''),
(5, 0, 2, '', '', 'wew', '2024-11-22', 'Pending', ''),
(6, 0, 2, '', '', 'Consultation', '2024-11-28', 'Pending', ''),
(7, 6, 2, '', '', 'Consultation', '2024-11-15', 'Pending', ''),
(8, 6, 2, '', '', 'wew', '2024-11-20', 'Pending', ''),
(9, 1, 1, '', 'florencioenrique69@gmail.com', 'Consultation', '2024-11-28', 'Accepted', 'dafegr'),
(10, 2, 1, '', '', '1213', '2024-11-29', 'Pending', ''),
(11, 6, 1, '', '', 'Consultation 123', '2024-11-13', 'Pending', ''),
(12, 5, 1, 'Florencio', '', '121143', '2024-11-22', 'Pending', ''),
(13, 1, 1, 'Florencio', '', 'Consultation', '2024-11-23', 'Pending', ''),
(14, 1, 1, 'Florencio', '1@florencio@domain.com', 'Consultation 123', '2024-11-27', 'Pending', ''),
(15, 1, 1, 'Florencio', 'florencioenrique69@gmail.com', 'wew1213', '2001-11-09', 'Pending', ''),
(16, 1, 1, 'Florencio', 'florencioenrique69@gmail.com', 'Sectrr', '2024-11-29', 'Pending', ''),
(17, 1, 1, 'Florencio', 'florencioenrique69@gmail.com', 'Consultation', '2024-11-23', 'Pending', ''),
(18, 1, 1, 'Florencio', 'florencioenrique69@gmail.com', 'wew', '2024-11-21', 'Pending', ''),
(19, 6, 1, 'Florencio', 'florencioenrique69@gmail.com', 'Consultation', '2024-11-27', 'Pending', 'QPYBOJJ7FU');

-- --------------------------------------------------------

--
-- Table structure for table `consultanttable`
--

CREATE TABLE `consultanttable` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `consultant_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultanttable`
--

INSERT INTO `consultanttable` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `zip_code`, `username`, `password`, `consultant_id`) VALUES
(1, 'Florencio', 'Enrique', 'florencioenrique69@gmail.com', '09078556862', 'Pob. 5 Hamtic Antique', '0', 'user1', 'user1', 1213),
(2, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', '', '12345', '12345', '12345', 13131),
(3, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', 'aaaaa', 'aaaaa', 3131),
(4, 'Kalbo', 'Pipoy', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', 'kalbo', 'kalbo', 3141),
(5, 'Lebron', 'James', 'florencioenrique1234@gmail.com', '09078556862', 'Foods', '12345', 'lebron', 'james', 3532),
(6, 'Flo', 'En', 'florencioenrique789@gmail.com', '09078556862', 'Foods', '12345', '1', '1', 5654643),
(7, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', 'user1', 'user1', 564),
(8, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', '1', '1', 45654),
(9, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', '1', '1', 5645);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip_code` int(11) NOT NULL,
  `expertise` varchar(255) NOT NULL,
  `medLicense` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `certificate_path` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `zip_code`, `expertise`, `medLicense`, `username`, `password`, `certificate_path`, `date`, `status`) VALUES
(1, 'John', 'Doe', 'john.doe@email.com', '555-123-4567', 'Antique Medical Center, San Jose de Buenavista, Antique, 5700, Philippines', 0, 'Family Medicine Doctor', 'MED12345', 'johndoe', 'P@ssword1', '', '', 'VERIFIED'),
(2, 'Sarah', 'Smith', 'sarah.smith@email.com', '0917-234-5678', '10.714423, 121.988812', 0, 'Family Medicine Doctor', 'MED23456', 'sarahsmith', '	P@ssword2', '', '', 'VERIFIED'),
(3, 'Michael', 'Johnson', 'michael.johnson@email.com', '0917-345-6789', 'Pob 1, Hamtic, Antique', 0, 'ENT Specialist', 'MED34567	', 'michaeljohnson', 'P@ssword3', '', '', 'VERIFIED'),
(4, 'Emily', 'Davis', 'emily.davis@email.com	', '0917-456-7890	', 'Bugang, Pandan, Antique', 0, 'Gastroenterologist', 'MED45678', 'emilydavis', 'P@ssword4', '', '', 'VERIFIED'),
(5, 'David', 'Lee', 'david.lee@email.com', '0917-567-8901	', 'Carit-an, Patnongon, Antique', 0, 'Allergist', 'MED56789', 'davidlee', 'P@ssword5\r\n', '', '', 'NOT VERIFIED'),
(6, 'Jessica', 'Brown', 'jessica.brown@email.com', '0917-678-9012	', 'Igbucagay, Hamtic, Antique', 0, 'Pulmonologist', 'MED67890', 'jessicabrown', 'P@ssword6', '', '', 'NOT VERIFIED'),
(7, 'Jessa', 'Miller', 'william.miller@email.com', '0917-789-0123', 'Madrangca, San Jose de Buenavista, Antique', 0, 'Pediatrician', 'MED78901	', 'williammiller', 'P@ssword7\r\n', '', '', 'NOT VERIFIED'),
(8, 'Jessica', 'Brown', 'jessica.brown@email.com', '0917-678-9012	', 'Igbucagay, Hamtic, Antique', 0, 'Endocrinologist', 'MED67890', 'jessicabrown', 'P@ssword6', '', '', 'NOT VERIFIED'),
(9, 'William', 'Miller', 'william.miller@email.com', '0917-789-0123', 'Madrangca, San Jose de Buenavista, Antique', 0, 'Nephrologist', 'MED78901	', 'williammiller', 'P@ssword7\r\n', '', '', 'NOT VERIFIED'),
(10, 'Olivia', 'Wilson', 'olivia.wilson@email.com', '0917-890-1234	', 'Poblacion, Tobias Fornier, Antique', 0, 'Pulmonologist', 'MED89012', 'oliviawilson	', 'P@ssword8', '', '', 'NOT VERIFIED'),
(11, 'James', 'Taylor', 'james.taylor@email.com', '0917-901-2345', 'Mag-aba, Pandan, Antique', 0, 'Rheumatologist	', 'MED90123', 'jamestaylor', 'P@ssword9\r\n', '', '', 'NOT VERIFIED'),
(12, 'Sophia', 'Martinez', 'sophia.martinez@email.com', '0917-012-3456', 'Igbarawan, Tobias Fornier, Antique', 0, 'Psychiatrist', 'MED01234', 'sophiamartinez', 'P@ssword10\r\n', '', '', 'NOT VERIFIED'),
(13, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', 'Foods', 12345, 'Doctor', '', '12345', '12345', '', '2024-10-31', 'VERIFIED'),
(14, 'Florencio', 'Enrique', 'enriqueflorencio@sac.edu.ph', '09078556862', 'Foods', 12345, '1', '', '1', '1', '', '2024-10-31', 'VERIFIED'),
(15, 'Florencio', 'Enrique', 'florencioenrique27499@gmail.com', '09078556862', 'Foods', 12345, '1', '', 'sample2@gmail.com', '123', '', '2024-11-03', 'VERIFIED'),
(16, 'Florencio', 'Enrique', 'enriqueflorencio@sac.edu.ph', '09078556862', 'Foods', 12345, '1', '1', '1', '1', 'uploads\\232.png', '2024-11-03', 'VERIFIED'),
(17, 'Florencio', 'Enrique', 'enriqueflorencio@sac.edu.ph', '09078556862', 'Pob. 5 Hamtic Antique', 12345, 'Albularyo', '115073', 'secret', 'secret', 'uploads\\232.png', '2024-11-03', 'VERIFIED');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `consultanttable`
--
ALTER TABLE `consultanttable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_account`
--
ALTER TABLE `admin_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `consultanttable`
--
ALTER TABLE `consultanttable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
