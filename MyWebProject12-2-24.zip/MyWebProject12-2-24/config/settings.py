import os

DEBUG = True
SECRET_KEY = "next_gen"

# Database settings for XAMPP MySQL
DATABASE_HOST = "localhost"
DATABASE_USER = "root"  # Default user for XAMPP
DATABASE_PASSWORD = ""    # Default password for XAMPP (empty)
DATABASE_NAME = "nextgen"  # Your database name
