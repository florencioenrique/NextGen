from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector
from mysql.connector import Error
from flask_mail import Mail, Message
from functools import wraps
import pandas as pd

app = Flask(__name__)
app.secret_key = "NextGen2024"

# Mail configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'florencioenrique69@gmail.com'
app.config['MAIL_PASSWORD'] = 'owaw sgni koox vvky'  # Use app password or secure method for real applications
app.config['MAIL_DEFAULT_SENDER'] = 'NextGen Health Diagnostic Web'

mail = Mail(app)

# Database connection settings
db_config = {
    'host': 'localhost',
    'database': 'nextgen',
    'user': 'root',        
    'password': ''           
}

# Function to check user credentials in the database
def validate_user(username, password):
    try:
        connection = mysql.connector.connect(**db_config)
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)
            query = "SELECT * FROM admin_account WHERE username = %s AND password = %s"
            cursor.execute(query, (username, password))
            user = cursor.fetchone()
            cursor.close()
            return user
    except Error as e:
        print("Error while connecting to MySQL", e)
    finally:
        if connection.is_connected():
            connection.close()
    return None

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "username" not in session:
            flash("Please log in to access the dashboard", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

@app.route("/")
def home():
    return render_template("adminLogin.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        user = validate_user(username, password)
        if user:
            session["username"] = username
            flash("Login successful!", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password", "danger")

    return render_template("adminLogin.html")

def get_total_users():
    try:
        connection = mysql.connector.connect(**db_config)
        if connection.is_connected():
            cursor = connection.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM consultanttable")
            total_patients = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM doctors")
            total_doctors = cursor.fetchone()[0]
            
            total_users = total_patients + total_doctors
            
            return total_users
    except Error as e:
        print("Error while connecting to MySQL", e)
        return None
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
total_users = get_total_users()
print("Total Users:", total_users)

def get_verified_doctors_count():
    try:
        connection = mysql.connector.connect(**db_config)
        if connection.is_connected():
            cursor = connection.cursor()
            
            # Query to count verified doctors
            cursor.execute("SELECT COUNT(*) FROM doctors WHERE status = 'VERIFIED'")
            total_verified_doctors = cursor.fetchone()[0]
            
            return total_verified_doctors
    except Error as e:
        print("Error while connecting to MySQL", e)
        return None
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
total_verified_doctors = get_verified_doctors_count()
print("Total Verified Doctors:", total_verified_doctors)

def count_registered_diseases():
    try:
        df = pd.read_csv('../datasets/disease.csv') 
        # Count unique diseases
        total_diseases = df['Disease'].nunique() 
        return total_diseases
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        return 0 

@app.route("/dashboard")
@login_required
def dashboard():
    pending = []
    verified = []
    activities = []
    total_users = get_total_users()
    total_verified_doctors = get_verified_doctors_count()
    total_diseases = count_registered_diseases()

    try:
        conn = mysql.connector.connect(**db_config)
        if conn.is_connected():
            cursor = conn.cursor(dictionary=True)

            # Fetch Pending Doctors
            cursor.execute("SELECT * FROM doctors WHERE status ='NOT VERIFIED'")
            pending = cursor.fetchall()

            # Fetch Verified Doctors
            cursor.execute("SELECT * FROM doctors WHERE status ='VERIFIED'")
            verified = cursor.fetchall()

    except Exception as e:
        print(f"Error: {e}")
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals() and conn.is_connected():
            conn.close()

    # Pass the data to admin.html
    return render_template("admin.html", username=session['username'], pending=pending, verified=verified, total_users=total_users, total_verified_doctors=total_verified_doctors,total_diseases=total_diseases)

@app.route("/logout")
def logout():
    session.pop("username", None)
    flash("You have been logged out", "info")
    return redirect(url_for("home"))

@app.route('/send_verification_email/<email>/<first_name>/<last_name>', methods=['GET'])
@login_required
def send_verification_email(email, first_name, last_name):
    conn = None
    cursor = None

    try:
        # Establish a database connection
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # Update the status of the doctor in the database
        cursor.execute("""
            UPDATE doctors
            SET status = 'VERIFIED'
            WHERE email = %s
        """, (email,))
        conn.commit()  # Commit the changes

        # Send the verification email
        msg = Message("Your Account was Verified",
                      recipients=[email])
        msg.body = f"Congratulations {first_name} {last_name}! Your account has been verified."
        mail.send(msg)  # Send the email

        flash("Verification email sent successfully and status updated to VERIFIED!", "success")
    except Exception as e:
        print(f"Error occurred: {e}")
        flash("Error sending email or updating status. Please try again.", "danger")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
    
    return redirect(url_for('dashboard'))

if __name__ == "__main__":
    app.run(port=5001)
