-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2024 at 07:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nextgen`
--

-- --------------------------------------------------------

--
-- Table structure for table `consultanttable`
--

CREATE TABLE `consultanttable` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultanttable`
--

INSERT INTO `consultanttable` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `zip_code`, `username`, `password`) VALUES
(1, 'Florencio', 'Enrique', 'florencioenrique69@gmail.com', '09078556862', 'Pob. 5 Hamtic Antique', '0', 'user1', 'user1'),
(2, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', '', '12345', '12345', '12345'),
(3, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', 'aaaaa', 'aaaaa'),
(4, 'Kalbo', 'Pipoy', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', 'kalbo', 'kalbo');

-- --------------------------------------------------------

--
-- Table structure for table `expertstable`
--

CREATE TABLE `expertstable` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `expertise` varchar(255) NOT NULL,
  `medLicense` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expertstable`
--

INSERT INTO `expertstable` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `expertise`, `medLicense`, `username`, `password`) VALUES
(1, 'Bossing', 'First Sample Doctor Last Name', 'sampledoc1@gmail.com', '09123456789', 'San Jose Antique', 'Allergist', '10132024', 'expert1', 'expert1'),
(2, 'Papa Jesus', 'Second Sample Doctor Last Name', 'sampledoc2@gmail.com', '09123456789', 'Pob. 5 Hamtic Antique', 'Neurologist', '10132024', 'expert2', 'expert2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `consultanttable`
--
ALTER TABLE `consultanttable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expertstable`
--
ALTER TABLE `expertstable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `consultanttable`
--
ALTER TABLE `consultanttable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `expertstable`
--
ALTER TABLE `expertstable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
