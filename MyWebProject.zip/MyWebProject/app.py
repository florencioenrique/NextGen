from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash
import numpy as np
import pandas as pd
import csv
import mysql.connector

app = Flask(__name__, template_folder='templates')

# Database connection
def get_db_connection():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='nextgen'
    )
    return connection

# Load data from CSV files
data = pd.read_csv('datasets/disease.csv')
data['Symptoms'] = data['Symptoms'].apply(lambda x: x.split(';'))

# Load disease descriptions
descriptions = {}
with open('datasets/disease_descriptions.csv', mode='r', newline='') as file:
    reader = csv.DictReader(file)
    for row in reader:
        descriptions[row['Disease']] = row['Description']

# Load doctors information from CSV
doctors = {}
with open('datasets/doctors.csv', mode='r', newline='') as file:
    reader = csv.DictReader(file)
    for row in reader:
        disease = row['Disease']
        doctor_info = {
            'doctor_type': row['Doctor_Type'],
            'doctor_name': row['Doctor_Name']
        }
        if disease in doctors:
            doctors[disease].append(doctor_info)
        else:
            doctors[disease] = [doctor_info]

@app.route('/add_disease', methods=['POST'])
def add_disease():
    disease = request.form['disease_name']
    symptoms = request.form['symptoms']

    if disease and symptoms:
        symptoms_list = [symptom.strip() for symptom in symptoms.split(';')]

        disease_exists = False
        existing_symptoms = []

        with open('datasets/disease.csv', mode='r', newline='') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0].strip() == disease:
                    disease_exists = True
                    existing_symptoms = row[1].split(';')
                    break

        if disease_exists:
            existing_symptoms_set = set(existing_symptoms)
            for symptom in symptoms_list:
                existing_symptoms_set.add(symptom)

            symptoms_str = ';'.join(existing_symptoms_set)
            updated_rows = []
            with open('datasets/disease.csv', mode='r', newline='') as file:
                reader = csv.reader(file)
                for row in reader:
                    if row[0].strip() == disease:
                        updated_rows.append([disease, symptoms_str]) 
                    else:
                        updated_rows.append(row)

            with open('datasets/disease.csv', mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerows(updated_rows)

        else:
            symptoms_str = ';'.join(symptoms_list)
            with open('datasets/disease.csv', mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([disease, symptoms_str]) 

    return redirect(url_for('experts_dashboard'))

# Prepare symptom and disease lists
symptoms = list(set([symptom for sublist in data['Symptoms'] for symptom in sublist]))
diseases = data['Disease'].unique()

X = np.array([[1 if symptom in symptoms_list else 0 for symptom in symptoms] for symptoms_list in data['Symptoms']])
y = np.array([[1 if d == disease else 0 for d in diseases] for disease in data['Disease']])

class SimpleNN:
    def __init__(self, input_size, hidden_size, output_size):
        self.W1 = np.random.rand(input_size, hidden_size)
        self.W2 = np.random.rand(hidden_size, output_size)

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_derivative(self, x):
        return x * (1 - x)

    def feedforward(self, X):
        self.hidden = self.sigmoid(np.dot(X, self.W1))
        self.output = self.sigmoid(np.dot(self.hidden, self.W2))
        return self.output

    def backpropagation(self, X, y, learning_rate):
        output_error = y - self.output
        output_delta = output_error * self.sigmoid_derivative(self.output)

        hidden_error = output_delta.dot(self.W2.T)
        hidden_delta = hidden_error * self.sigmoid_derivative(self.hidden)

        self.W2 += self.hidden.T.dot(output_delta) * learning_rate
        self.W1 += X.T.dot(hidden_delta) * learning_rate

    def train(self, X, y, epochs, learning_rate):
        for _ in range(epochs):
            self.feedforward(X)
            self.backpropagation(X, y, learning_rate)

nn = SimpleNN(len(symptoms), 5, len(diseases))
nn.train(X, y, epochs=10000, learning_rate=0.1)



@app.route('/')
def home():
    return render_template('home.html')

@app.route('/userReg')
def user_registration():
    return render_template('userReg.html')

@app.route('/registration_form', methods=['GET', 'POST'])
def registration_form():
    if request.method == 'POST':
        user_type = request.form['userType']
        first_name = request.form['firstName']
        last_name = request.form['lastName']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        zip_code = request.form['zipCode']
        username = request.form['username']
        password = request.form['password']

        # If user is a doctor, get additional fields
        medical_license = request.form.get('medicalLicense', '')
        specialization = request.form.get('specialization', '')
        clinic_name = request.form.get('clinicName', '')
        clinic_street = request.form.get('clinicStreet', '')
        clinic_city = request.form.get('clinicCity', '')
        clinic_state = request.form.get('clinicState', '')
        clinic_zip_code = request.form.get('clinicZipCode', '')
        reference1_name = request.form.get('reference1Name', '')
        reference1_contact = request.form.get('reference1Contact', '')
        reference2_name = request.form.get('reference2Name', '')
        reference2_contact = request.form.get('reference2Contact', '')

        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            # Insert data into your consultant or doctor table based on user type
            if user_type == 'consultant':
                cursor.execute('''
                    INSERT INTO consultanttable (first_name, last_name, email, phone, address, zip_code, username, password)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                ''', (first_name, last_name, email, phone, address, zip_code, username, password))
            elif user_type == 'doctor':
                cursor.execute('''
                    INSERT INTO doctortable (first_name, last_name, email, phone, address, username, password,
                    medical_license, specialization, clinic_name, clinic_street, clinic_city, clinic_state, clinic_zip_code,
                    reference1_name, reference1_contact, reference2_name, reference2_contact)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ''', (first_name, last_name, email, phone, address, zip_code, username, password,
                      medical_license, specialization, clinic_name, clinic_street, clinic_city, clinic_state, clinic_zip_code,
                      reference1_name, reference1_contact, reference2_name, reference2_contact))

            conn.commit()
            flash('Registration successful!', 'success')
            return redirect(url_for('success_page'))  # Redirect to a success page after registration

        except Exception as e:
            print(f"Error occurred: {e}")
            flash('Registration failed. Please try again.', 'danger')
            return redirect(url_for('registration_form'))

        finally:
            cursor.close()
            conn.close()

    return render_template('userReg.html')  # Render your registration template

@app.route('/success_page')
def success_page():
    return render_template('home.html')  # Create a success template


@app.route('/consultant')
def consultant():
    if 'user' not in session:
        return redirect(url_for('home'))
    
    # Fetch doctors from the database
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id, first_name, expertise FROM expertstable")  # Assuming id is the unique fetch ID
    doctors = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('consultant.html', symptoms=symptoms, doctors=doctors)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    symptoms_input = [symptom.capitalize() for symptom in data['symptoms']]  # Capitalize input

    not_found_symptoms = [symptom for symptom in symptoms_input if symptom not in symptoms]
    if not_found_symptoms:
        return jsonify({'error': f"Symptoms not found: {', '.join(not_found_symptoms)}"}), 400

    sample_input = np.array([[1 if symptom in symptoms_input else 0 for symptom in symptoms]])
    output = nn.feedforward(sample_input)

    predictions = {disease: output[0][i] for i, disease in enumerate(diseases)}
    sorted_predictions = sorted(predictions.items(), key=lambda item: item[1], reverse=True)

    top_predictions = [
        {
            'disease': sorted_predictions[i][0],
            'probability': sorted_predictions[i][1] * 100,  # Convert to percentage
            'description': descriptions.get(sorted_predictions[i][0], ''),
            'doctors': doctors.get(sorted_predictions[i][0], [])
        } 
        for i in range(min(5, len(sorted_predictions)))
    ]

    most_likely = top_predictions[0] if top_predictions else {}
    least_likely = sorted_predictions[-1] if len(sorted_predictions) > 1 else None

    return jsonify({
        'most_likely': most_likely,
        'least_likely': least_likely,
        'top_predictions': top_predictions
    })

# Log in credentials for experts and consultants
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM consultanttable WHERE username = %s AND password = %s", (username, password))
    user = cursor.fetchone()
    connection.close()

    if user:
        session['user'] = username  # Store username in session
        return redirect(url_for('consultant'))
    else:
        return "Invalid username or password", 401
    
@app.route('/expert_login', methods=['POST'])
def expert_login():
    username = request.form['username']
    password = request.form['password']

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True) 
    cursor.execute("SELECT * FROM expertstable WHERE username = %s AND password = %s", (username, password))
    expert = cursor.fetchone()  # Fetch the expert details
    connection.close()

    if expert:
        session['expert_name'] = expert['first_name']
        session['expert_username'] = expert['username']
        return redirect(url_for('experts_dashboard'))
    else:
        return "Invalid username or password", 401

# Expert dashboard route
@app.route('/experts_dashboard')
def experts_dashboard():
    if 'expert_name' not in session:
        return redirect(url_for('home'))
    
    expert_name = session['expert_name']

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT first_name, last_name, email FROM consultanttable")
    consultants = cursor.fetchall()
    
    cursor.close()
    conn.close()

    return render_template('experts.html', expert_name=expert_name, consultants=consultants)

if __name__ == '__main__':
    app.secret_key = 'your_super_secret_key_12345'
    app.run(debug=True)
