import pymysql
from pymysql.cursors import DictCursor

def create_connection():
    try:
        # Establish a database connection
        connection = pymysql.connect(
            host='localhost',
            user='root',          # Your MySQL username
            password='',          # Your MySQL password (leave blank if none)
            database='nextgen',   # Your database name
            cursorclass=DictCursor
        )
        print("Connection to the database was successful!")
        return connection
    except pymysql.MySQLError as e:
        print(f"Error connecting to the database: {e}")
        return None
