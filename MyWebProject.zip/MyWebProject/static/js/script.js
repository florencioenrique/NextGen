// Change the message based on the selected user type
document.querySelectorAll('input[name="flexRadioDefault"]').forEach((radio) => {
    radio.addEventListener('change', function() {
        const welcomeMessage = document.getElementById('welcomeMessage');
        const userForm = document.getElementById('userForm');
        const submitButton = userForm.querySelector('button[type="submit"]');

        // Show the message and hide the dropdown
        welcomeMessage.innerText = this.value === 'Consultant' ? 'Welcome User' : 'Welcome Doctors';
        welcomeMessage.style.display = 'block';
        document.getElementById('userTypeButton').style.display = 'none';

        // Enable the input fieldsy
        userForm.querySelectorAll('input').forEach(input => {
            input.disabled = false; // Enable input fields
        });
        submitButton.disabled = false; // Enable submit button
    });
});

// Password visibility toggle functionality
document.getElementById('togglePassword').addEventListener('click', function () {
    const passwordInput = document.getElementById('exampleInputPassword1');
    const eyeIcon = document.getElementById('eyeIcon');

    // Toggle the type attribute
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    
    // Toggle the eye icon
    eyeIcon.classList.toggle('fa-eye');
    eyeIcon.classList.toggle('fa-eye-slash');
});