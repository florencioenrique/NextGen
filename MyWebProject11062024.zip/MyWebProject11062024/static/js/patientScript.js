let currentStep = 'who';
    const patientInfo = {
        type: '',
        gender: '',
        age: '',
        symptoms: ''
    };

    function showSection(sectionId) {
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        
        document.getElementById(sectionId).classList.add('active');
        event.target.closest('.nav-link').classList.add('active');
        
        if (sectionId !== 'symptoms') {
            document.getElementById('symptomsProgress').classList.add('d-none');
        }
    }

    function updateProgress(step) {
        document.querySelectorAll('.progress-step').forEach(el => {
            if (el.dataset.step === step) {
                el.classList.add('active');
            } else if (Array.from(el.classList).includes('active')) {
                el.classList.remove('active');
                el.classList.add('completed');
            }
        });
    }

    function selectDiagnosis(type) {
        patientInfo.type = type;
        document.getElementById('whoSection').classList.add('d-none');
        document.getElementById('symptomsProgress').classList.remove('d-none');
        
        if (type === 'OTHERS') {
            document.getElementById('genderSection').classList.remove('d-none');currentStep = 'gender';
        } else {
            // For 'ME' option: Auto-fill gender and age from profile
            patientInfo.gender = 'Male'; // This would come from profile
            patientInfo.age = '30'; // This would come from profile
            
            // Mark gender and age steps as completed
            updateProgress('gender');
            updateProgress('age');
            
            // Show symptoms section directly
            document.getElementById('symptomsSection').classList.remove('d-none');
            currentStep = 'symptoms';
        }
        updateProgress(currentStep);
    }

    function selectGender(gender) {
        patientInfo.gender = gender;
        document.getElementById('genderSection').classList.add('d-none');
        document.getElementById('ageSection').classList.remove('d-none');
        currentStep = 'age';
        updateProgress(currentStep);
    }

    function submitAge() {
        const age = document.getElementById('ageInput').value;
        if (!age) {
            alert('Please enter an age');
            return;
        }
        patientInfo.age = age;
        document.getElementById('ageSection').classList.add('d-none');
        document.getElementById('symptomsSection').classList.remove('d-none');
        currentStep = 'symptoms';
        updateProgress(currentStep);
    }

    function submitSymptoms() {
        const symptoms = document.querySelector('#symptomsSection textarea').value;
        if (!symptoms) {
            alert('Please describe your symptoms');
            return;
        }
        patientInfo.symptoms = symptoms;

        // Create results card
        const resultsHtml = `
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Diagnosis Results</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6>Patient Information:</h6>
                        <ul class="list-unstyled">
                            <li><strong>Type:</strong> ${patientInfo.type}</li>
                            <li><strong>Gender:</strong> ${patientInfo.gender}</li>
                            <li><strong>Age:</strong> ${patientInfo.age}</li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <h6>Reported Symptoms:</h6>
                        <p>${patientInfo.symptoms}</p>
                    </div>
                    <div>
                        <h6>Recommended Actions:</h6>
                        <ul>
                            <li>Schedule an appointment with a doctor</li>
                            <li>Monitor symptoms for any changes</li>
                            <li>Keep track of any new symptoms</li>
                        </ul>
                    </div>
                    <div class="mt-4">
                        <button class="btn btn-blue me-2" onclick="showSection('appointments')">
                            Schedule Appointment
                        </button>
                        <button class="btn btn-outline-primary" onclick="startNewDiagnosis()">
                            Start New Diagnosis
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Replace symptoms section with results
        document.getElementById('symptomsSection').classList.add('d-none');
        const resultsElement = document.createElement('div');
        resultsElement.innerHTML = resultsHtml;
        document.getElementById('symptoms').appendChild(resultsElement);

        // Add to diagnosis history
        addToDiagnosisHistory(patientInfo);
    }

    function addToDiagnosisHistory(diagnosis) {
        const historySection = document.getElementById('history');
        const noHistoryMessage = historySection.querySelector('.text-center');
        
        if (noHistoryMessage) {
            noHistoryMessage.remove();
        }

        const historyEntry = `
            <div class="card mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">Diagnosis Record</h6>
                            <p class="text-muted mb-0">Date: ${new Date().toLocaleDateString()}</p>
                        </div>
                        <button class="btn btn-outline-primary btn-sm" onclick="viewDiagnosisDetails(this)">
                            View Details
                        </button>
                    </div>
                </div>
            </div>
        `;

        const historyContainer = document.createElement('div');
        historyContainer.innerHTML = historyEntry;
        historySection.querySelector('.card-body').appendChild(historyContainer);
    }

    function startNewDiagnosis() {
        // Reset all sections and progress
        document.querySelectorAll('.progress-step').forEach(step => {
            step.classList.remove('active', 'completed');
        });
        document.querySelectorAll('.progress-step')[0].classList.add('active');

        // Clear previous diagnosis sections
        const symptomsSection = document.getElementById('symptoms');
        symptomsSection.innerHTML = '';

        const sectionsHtml = `
            <div class="card mb-4" id="whoSection">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Who would like to be diagnosed?</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex gap-3">
                        <button class="btn btn-blue" onclick="selectDiagnosis('ME')">ME</button>
                        <button class="btn btn-blue" onclick="selectDiagnosis('OTHERS')">OTHERS</button>
                    </div>
                </div>
            </div>
        `;
        
        symptomsSection.innerHTML = sectionsHtml;
        currentStep = 'who';
        
        // Reset patient info
        patientInfo.type = '';
        patientInfo.gender = '';
        patientInfo.age = '';
        patientInfo.symptoms = '';
    }

    function viewDiagnosisDetails(button) {
        // Implementation for viewing diagnosis details
        alert('Viewing diagnosis details... (Implementation pending)');
    }
    

    // Initialize active section based on URL hash
    window.addEventListener('load', () => {
        const hash = window.location.hash.slice(1) || 'overview';
        showSection(hash);
    });