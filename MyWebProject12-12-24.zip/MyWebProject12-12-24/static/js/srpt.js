const currentHour = new Date().getHours();
    let message = "";

    if (currentHour >= 5 && currentHour < 12) {
      message = "Good Morning!";
    } else if (currentHour >= 12 && currentHour < 18) {
      message = "Good Afternoon!";
    } else {
      message = "Good Evening!";
    }

    document.getElementById("greeting").textContent = message;