import subprocess

# Run admin.py
subprocess.Popen(["python", "admin.py"])

# Run app.py
subprocess.Popen(["python", "app.py"])
