let selectedUser, selectedGender, selectedAge = [];
const sidebar = document.getElementById('sidebar');

const step1 = document.getElementById('step1');
const step2 = document.getElementById('step2');
const step3 = document.getElementById('step3');
const step4 = document.getElementById('step4');
const step5 = document.getElementById('step5');

const meCard = document.getElementById('meCard');
const othersCard = document.getElementById('othersCard');
const proceedToSymptoms = document.getElementById('proceedToSymptoms');
        
function updateProgress() {
    let currentStep = 0;
    if (selectedUser) currentStep++;
    if (selectedGender) currentStep++;
    if (selectedAge) currentStep++;
    if (symptoms.length > 0) currentStep++;
}

function showStep(stepToShow) {
    [step1, step2, step3, step4, step5].forEach(step => step.style.display = 'none');
    stepToShow.style.display = 'block';
}
        
// const availableSymptoms = {{ symptoms|tojson }};



meCard.addEventListener('click', function() {
    selectedUser = "Me";
    showStep(step4);
});

othersCard.addEventListener('click', function() {
    selectedUser = "Others";
    showStep(step2);
});

document.querySelectorAll('#maleCard, #femaleCard, #otherCard').forEach(card => {
    card.addEventListener('click', function() {
        selectedGender = this.querySelector('.card-title').textContent;
        updateProgress();
        showStep(step3);
    });
});

proceedToSymptoms.addEventListener('click', function() {
    selectedAge = document.getElementById('age').value;
    showStep(step4);
});
