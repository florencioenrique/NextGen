-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2024 at 05:57 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nextgen`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_account`
--

INSERT INTO `admin_account` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `consultanttable`
--

CREATE TABLE `consultanttable` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultanttable`
--

INSERT INTO `consultanttable` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `zip_code`, `username`, `password`) VALUES
(1, 'Florencio', 'Enrique', 'florencioenrique69@gmail.com', '09078556862', 'Pob. 5 Hamtic Antique', '0', 'user1', 'user1'),
(2, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', '', '12345', '12345', '12345'),
(3, 'Florencio', 'Enrique', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', 'aaaaa', 'aaaaa'),
(4, 'Kalbo', 'Pipoy', 'florencioenrique456@gmail.com', '09078556862', 'Foods', '12345', 'kalbo', 'kalbo'),
(5, 'Lebron', 'James', 'florencioenrique1234@gmail.com', '09078556862', 'Foods', '12345', 'lebron', 'james'),
(6, 'Flo', 'En', 'florencioenrique789@gmail.com', '09078556862', 'Foods', '12345', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `pendingdoctors_table`
--

CREATE TABLE `pendingdoctors_table` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `medLicense` int(11) NOT NULL,
  `experties` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pendingdoctors_table`
--

INSERT INTO `pendingdoctors_table` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `zip_code`, `username`, `password`, `medLicense`, `experties`, `date`) VALUES
(1, 'Flo', 'En', 'florencioenrique27499@gmail.com', '1', 'Address4', '1', '1', '1', 0, '1', '2024-09-21');

-- --------------------------------------------------------

--
-- Table structure for table `verified_doctors`
--

CREATE TABLE `verified_doctors` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip_code` int(11) NOT NULL,
  `expertise` varchar(255) NOT NULL,
  `medLicense` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `verified_doctors`
--

INSERT INTO `verified_doctors` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `zip_code`, `expertise`, `medLicense`, `username`, `password`, `date_created`) VALUES
(1, 'John', 'Doe', 'john.doe@email.com', '555-123-4567', 'Antique Medical Center, San Jose de Buenavista, Antique, 5700, Philippines', 0, 'Family Medicine Doctor', 'MED12345', 'johndoe', 'P@ssword1', ''),
(2, 'Sarah', 'Smith', 'sarah.smith@email.com', '0917-234-5678', '10.714423, 121.988812', 0, 'Family Medicine Doctor', 'MED23456', 'sarahsmith', '	P@ssword2', ''),
(3, 'Michael', 'Johnson', 'michael.johnson@email.com', '0917-345-6789', 'Pob 1, Hamtic, Antique', 0, 'ENT Specialist', 'MED34567	', 'michaeljohnson', 'P@ssword3', ''),
(4, 'Emily', 'Davis', 'emily.davis@email.com	', '0917-456-7890	', 'Bugang, Pandan, Antique', 0, 'Gastroenterologist', 'MED45678', 'emilydavis', 'P@ssword4', ''),
(5, 'David', 'Lee', 'david.lee@email.com', '0917-567-8901	', 'Carit-an, Patnongon, Antique', 0, 'Allergist', 'MED56789', 'davidlee', 'P@ssword5\r\n', ''),
(6, 'Jessica', 'Brown', 'jessica.brown@email.com', '0917-678-9012	', 'Igbucagay, Hamtic, Antique', 0, 'Pulmonologist', 'MED67890', 'jessicabrown', 'P@ssword6', ''),
(7, 'Jessa', 'Miller', 'william.miller@email.com', '0917-789-0123', 'Madrangca, San Jose de Buenavista, Antique', 0, 'Pediatrician', 'MED78901	', 'williammiller', 'P@ssword7\r\n', ''),
(8, 'Jessica', 'Brown', 'jessica.brown@email.com', '0917-678-9012	', 'Igbucagay, Hamtic, Antique', 0, 'Endocrinologist', 'MED67890', 'jessicabrown', 'P@ssword6', ''),
(9, 'William', 'Miller', 'william.miller@email.com', '0917-789-0123', 'Madrangca, San Jose de Buenavista, Antique', 0, 'Nephrologist', 'MED78901	', 'williammiller', 'P@ssword7\r\n', ''),
(10, 'Olivia', 'Wilson', 'olivia.wilson@email.com', '0917-890-1234	', 'Poblacion, Tobias Fornier, Antique', 0, 'Pulmonologist', 'MED89012', 'oliviawilson	', 'P@ssword8', ''),
(11, 'James', 'Taylor', 'james.taylor@email.com', '0917-901-2345', 'Mag-aba, Pandan, Antique', 0, 'Rheumatologist	', 'MED90123', 'jamestaylor', 'P@ssword9\r\n', ''),
(12, 'Sophia', 'Martinez', 'sophia.martinez@email.com', '0917-012-3456', 'Igbarawan, Tobias Fornier, Antique', 0, 'Psychiatrist', 'MED01234', 'sophiamartinez', 'P@ssword10\r\n', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `consultanttable`
--
ALTER TABLE `consultanttable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pendingdoctors_table`
--
ALTER TABLE `pendingdoctors_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `verified_doctors`
--
ALTER TABLE `verified_doctors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_account`
--
ALTER TABLE `admin_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `consultanttable`
--
ALTER TABLE `consultanttable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pendingdoctors_table`
--
ALTER TABLE `pendingdoctors_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `verified_doctors`
--
ALTER TABLE `verified_doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
