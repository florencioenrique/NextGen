import mysql.connector
from flask import Flask, render_template, request

app = Flask(__name__)

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',    # Replace with your MySQL username (default is usually 'root')
    'password': '',     # Replace with your MySQL password (default is usually empty for 'root')
    'database': 'nextgen'  # The name of your database
}

# Function to get user names and IDs
def get_users():
    connection = mysql.connector.connect(**DB_CONFIG)
    cursor = connection.cursor()
    cursor.execute("SELECT id, first_name FROM expertstable")  # Change to your actual table name and columns
    users = cursor.fetchall()
    connection.close()
    return users

# Function to get the address based on user ID
def get_address(user_id):
    connection = mysql.connector.connect(**DB_CONFIG)
    cursor = connection.cursor()
    cursor.execute("SELECT address FROM expertstable WHERE id = %s", (user_id,))
    address = cursor.fetchone()
    connection.close()
    return address[0] if address else None

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        address = get_address(user_id)

        if address:
            return render_template('combined.html', address=address, users=get_users(), show_map=True)
        else:
            return render_template('combined.html', users=get_users(), error=f"Address not found for user ID {user_id}.")

    users = get_users()  # Fetch user names and IDs for GET request
    return render_template('combined.html', users=users)

if __name__ == '__main__':
    app.run(debug=True)
