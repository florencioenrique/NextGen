from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import requests

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///map.db'  # Your DB URI
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    address = db.Column(db.String, nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)

def geocode_address(address):
    # Use Nominatim for geocoding without an API key
    url = f'https://nominatim.openstreetmap.org/search?q={address}&format=json'
    response = requests.get(url)
    data = response.json()
    if data:
        return float(data[0]['lat']), float(data[0]['lon'])
    return None, None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        address = request.form['address']
        
        lat, lon = geocode_address(address)
        if lat is not None and lon is not None:
            new_user = User(name=name, address=address, latitude=lat, longitude=lon)
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('index'))
        else:
            return "Address not found. Please try again."
    
    return render_template('register.html')

@app.route('/search', methods=['POST'])
def search():
    name = request.form['search_name']
    user = User.query.filter_by(name=name).first()
    
    if user:
        return render_template('map.html', locations=[{'lat': user.latitude, 'lng': user.longitude, 'address': user.address}])
    else:
        return "User not found."

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables within the app context
    app.run(debug=True)
