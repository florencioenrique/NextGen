let selectedUser, selectedGender, selectedAge = [];
let symptoms = [];
const sidebar = document.getElementById('sidebar');
const patientNav = document.getElementById('patientNav');
const symptomsNav = document.getElementById('symptomsNav');
const predictedNav = document.getElementById('predictedNav');
const patientDetails = document.getElementById('patientDetails');
const progressCircle = document.getElementById('progressCircle');
const progress = document.getElementById('progress');
const percentage = document.getElementById('percentage');

const step1 = document.getElementById('step1');
const step2 = document.getElementById('step2');
const step3 = document.getElementById('step3');
const step4 = document.getElementById('step4'); // Remove step5 reference

const meCard = document.getElementById('meCard');
const othersCard = document.getElementById('othersCard');
const proceedToSymptoms = document.getElementById('proceedToSymptoms');
const symptomInput = document.getElementById('symptomInput');
const addSymptom = document.getElementById('addSymptom');
const symptomsContainer = document.getElementById('symptomsContainer');
const proceedToPrediction = document.getElementById('proceedToPrediction');
const predictionResult = document.getElementById('predictionResult');
const startOver = document.getElementById('startOver');

// Function to update the progress bar
function updateProgress() {
    let totalSteps = 4;  // Now the process only has 4 steps
    let currentStep = 0;
    
    if (selectedUser) currentStep++;
    if (selectedGender) currentStep++;
    if (selectedAge) currentStep++;
    if (symptoms.length > 0) currentStep++;
    
    let percent = (currentStep / totalSteps) * 100;
    progressCircle.style.background = `conic-gradient(#4d7094 ${percent * 3.6}deg, #7dafe6 0deg)`;
    percentage.textContent = `${Math.round(percent)}%`;
}

// Function to show the respective step
function showStep(stepToShow) {
    [step1, step2, step3, step4].forEach(step => step.style.display = 'none');
    stepToShow.style.display = 'block';
}

// AJAX function to handle symptom submission and prediction
$(document).ready(function() {
    $('#symptomForm').on('submit', function(event) {
        event.preventDefault();
        const symptomsInput = $('#symptoms').val().trim();
        $('#error-message').text('');

        if (symptomsInput === '') {
            $('#error-message').text("Please input symptoms.");
            return;
        }

        const symptoms = symptomsInput.split(',').map(symptom => symptom.trim());

        $.ajax({
            url: '/predict',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ symptoms }),
            success: function(response) {
                // Clear previous results
                $('#most-likely').empty();
                $('#predictions').empty();

                // Display most likely disease
                if (response.most_likely) {
                    const mostLikelyProbability = response.most_likely.probability;
                    const mostLikelyDoctors = response.most_likely.doctors && response.most_likely.doctors.length > 0 
                        ? response.most_likely.doctors 
                        : [];

                    // Append the most likely disease details
                    $('#most-likely').append(`
                        <li class="list-group-item list-group-item-success">
                            <strong>${response.most_likely.disease}:</strong>
                            <span class="percentage-text">${mostLikelyProbability.toFixed(2)}%</span><br>
                            ${response.most_likely.description}<br>
                            <small>Doctors:</small>
                            <ul id="most-likely-doctors">
                                ${mostLikelyDoctors.length > 0 
                                    ? mostLikelyDoctors.map((doctor) => `
                                        <li>
                                            Doctor Name: ${doctor.name} - Address: ${doctor.address}<br>
                                            <form class="view-doctor-form" action="/fetch-doctor" method="POST">
                                                <input type="hidden" name="doctor_id" value="${doctor.id}">
                                                <input type="hidden" name="doctor_address" value="${doctor.address}">
                                                <button type="submit" class="view-doctor">View Location for ${doctor.name}</button>
                                            </form>
                                            <div id="map-container-${doctor.id}" style="height: 400px; display: none;"></div> <!-- Unique map container for each doctor -->
                                        </li>
                                    `).join('') 
                                    : '<li>No doctors available</li>'
                                }
                            </ul>
                        </li>
                    `);

                    // Add event listeners for viewing doctor location
                    $('.view-doctor-form').on('submit', function(event) {
                        event.preventDefault();
                        const doctorId = $(this).find('input[name="doctor_id"]').val();
                        const doctorAddress = $(this).find('input[name="doctor_address"]').val();
                        const mapContainer = $(`#map-container-${doctorId}`);
                        mapContainer.show();
                        if (!mapContainer.hasClass('map-initialized')) {
                            mapContainer.addClass('map-initialized');
                            const map = L.map(mapContainer[0]).setView([0, 0], 2);
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                maxZoom: 19,
                                attribution: '© OpenStreetMap'
                            }).addTo(map);

                            // Geocode the doctor's address
                            fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(doctorAddress)}`)
                                .then(response => response.json())
                                .then(data => {
                                    if (data && data.length > 0) {
                                        const lat = data[0].lat;
                                        const lon = data[0].lon;
                                        map.setView([lat, lon], 13);
                                        L.marker([lat, lon]).addTo(map)
                                            .bindPopup(doctorAddress)
                                            .openPopup();
                                    } else {
                                        alert('Location not found for the given address.');
                                    }
                                })
                                .catch(error => {
                                    console.error('Error fetching geolocation:', error);
                                });
                        }
                    });
                }

                // Display other predicted diseases
                const mostLikelyDisease = response.most_likely ? response.most_likely.disease : null;
                response.top_predictions.forEach(function(prediction, predictionIndex) {
                    if (prediction.disease !== mostLikelyDisease) {
                        const probability = prediction.probability;
                        const predictionDoctors = prediction.doctors && prediction.doctors.length > 0 
                            ? prediction.doctors 
                            : [];

                        $('#predictions').append(`
                            <li class="list-group-item">
                                <strong>${prediction.disease}:</strong>
                                <span class="percentage-text">${probability.toFixed(2)}%</span><br>
                                ${prediction.description}<br>
                                <small>Doctors:</small>
                                <ul id="prediction-doctors-${predictionIndex}">
                                    ${predictionDoctors.length > 0 
                                        ? predictionDoctors.map((doctor) => `
                                            <li>
                                                Doctor Name: ${doctor.name} - Address: ${doctor.address}
                                            </li>
                                        `).join('') 
                                        : '<li>No doctors available</li>'
                                    }
                                </ul>
                            </li>
                        `);
                    }
                });

                if (response.most_likely || response.top_predictions.length > 0) {
                    $('#prediction-section').show();
                } else {
                    $('#prediction-section').hide();
                }

                // Update progress to 100% on prediction completion
                progressCircle.style.background = `conic-gradient(#4d7094 360deg, #7dafe6 0deg)`;
                percentage.textContent = '100%';
            },
            error: function(error) {
                $('#predictions').empty();
                $('#error-message').text(error.responseJSON?.error || "An error occurred during prediction.");
            }
        });
    });
});

// Card click event for "Me"
meCard.addEventListener('click', function() {
    selectedUser = "Me";
    patientDetails.innerHTML = '<li class="sub-nav-item">User: Me</li>';
    updateProgress();
    showStep(step4);
});

// Card click event for "Others"
othersCard.addEventListener('click', function() {
    selectedUser = "Others";
    patientDetails.innerHTML = '<li class="sub-nav-item">User: Others</li>';
    updateProgress();
    showStep(step2);
});

// Gender card click event
document.querySelectorAll('#maleCard, #femaleCard, #otherCard').forEach(card => {
    card.addEventListener('click', function() {
        selectedGender = this.querySelector('.card-title').textContent;
        patientDetails.innerHTML += `<li class="sub-nav-item">Gender: ${selectedGender}</li>`;
        updateProgress();
        showStep(step3);
    });
});

// Proceed to symptoms event
proceedToSymptoms.addEventListener('click', function() {
    selectedAge = document.getElementById('ageInput').value;
    
    // Validate that an age is entered
    if (!selectedAge) {
        alert("Please enter a valid age.");
        return;
    }

    patientDetails.innerHTML += `<li class="sub-nav-item">Age: ${selectedAge}</li>`;
    
    // Update progress and move to symptoms selection
    updateProgress();
    showStep(step4);
});

// Add symptom event
addSymptom.addEventListener('click', function() {
    const symptom = symptomInput.value.trim();
    if (symptom) {
        symptoms.push(symptom);
        symptomsContainer.innerHTML += `<li>${symptom}</li>`;
        symptomInput.value = '';
        updateProgress();
    }
});

// Start over event
startOver.addEventListener('click', function() {
    selectedUser = null;
    selectedGender = null;
    selectedAge = null;
    symptoms = [];
    patientDetails.innerHTML = '';
    symptomsContainer.innerHTML = '';
    updateProgress();
    showStep(step1);
});
