import numpy as np

class NeuralNetwork:
    def __init__(self):
        self.input_size = None
        self.hidden_size = 5
        self.output_size = None
        self.W1 = None
        self.W2 = None

    def train(self, X, y, input_size, output_size, epochs=10000, learning_rate=0.1):
        self.input_size = input_size
        self.output_size = output_size
        self.W1 = np.random.rand(input_size, self.hidden_size)
        self.W2 = np.random.rand(self.hidden_size, output_size)

        for _ in range(epochs):
            self.feedforward(X)
            self.backpropagation(X, y, learning_rate)

    def feedforward(self, X):
        self.hidden = self.sigmoid(np.dot(X, self.W1))
        self.output = self.sigmoid(np.dot(self.hidden, self.W2))
        return self.output

    def backpropagation(self, X, y, learning_rate):
        output_error = y - self.output
        output_delta = output_error * self.sigmoid_derivative(self.output)
        hidden_error = output_delta.dot(self.W2.T)
        hidden_delta = hidden_error * self.sigmoid_derivative(self.hidden)

        self.W2 += self.hidden.T.dot(output_delta) * learning_rate
        self.W1 += X.T.dot(hidden_delta) * learning_rate

    def predict(self, symptoms, disease_model):
        X = np.array([[1 if symptom in symptoms else 0 for symptom in disease_model.get_symptoms()]])
        output = self.feedforward(X)
        predictions = {disease: output[0][i] for i, disease in enumerate(disease_model.get_diseases())}
        sorted_predictions = sorted(predictions.items(), key=lambda item: item[1], reverse=True)
        return sorted_predictions[:5]

    @staticmethod
    def sigmoid(x):
        return 1 / (1 + np.exp(-x))

    @staticmethod
    def sigmoid_derivative(x):
        return x * (1 - x)
