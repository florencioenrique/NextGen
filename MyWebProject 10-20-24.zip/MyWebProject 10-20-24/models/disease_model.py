import pandas as pd
import csv
from models.user_model import get_db_connection

class DiseaseModel:
    def __init__(self):
        # Load disease data
        self.data = pd.read_csv('datasets/disease.csv')
        self.data['Symptoms'] = self.data['Symptoms'].apply(lambda x: x.split(';'))

        # Load disease descriptions
        self.descriptions = {}
        with open('datasets/disease_descriptions.csv', mode='r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self.descriptions[row['Disease']] = row['Description']

        # Load doctors information
        self.doctors = {}
        with open('datasets/doctors.csv', mode='r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                disease = row['Disease']
                doctor_type = row['Doctor_Type']
                if disease not in self.doctors:
                    self.doctors[disease] = []
                self.doctors[disease].append(doctor_type)

    def fetch_matched_doctors(self, disease):
        matched_doctors = []
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT first_name FROM expertstable WHERE expertise = %s", (disease,))
        doctors_data = cursor.fetchall()
        for doctor in doctors_data:
            matched_doctors.append(doctor['first_name'])
        cursor.close()
        conn.close()
        return matched_doctors

    def get_symptoms(self):
        symptoms = list(set([symptom for sublist in self.data['Symptoms'] for symptom in sublist]))
        return symptoms

    def get_diseases(self):
        return self.data['Disease'].unique()
