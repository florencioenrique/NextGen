from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector
from mysql.connector import Error
from flask_mail import Mail, Message

app = Flask(__name__)
app.secret_key = "NextGen2024"

# Mail configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'florencioenrique69@gmail.com'
app.config['MAIL_PASSWORD'] = 'owaw sgni koox vvky'  # Use app password or secure method for real applications
app.config['MAIL_DEFAULT_SENDER'] = 'NextGen Health Diagnostic Web'

mail = Mail(app)

# Database connection settings
db_config = {
    'host': 'localhost',
    'database': 'nextgen',
    'user': 'root',        
    'password': ''           
}

# Function to check user credentials in the database
def validate_user(username, password):
    try:
        connection = mysql.connector.connect(**db_config)
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)
            query = "SELECT * FROM admin_account WHERE username = %s AND password = %s"
            cursor.execute(query, (username, password))
            user = cursor.fetchone()
            cursor.close()
            return user
    except Error as e:
        print("Error while connecting to MySQL", e)
    finally:
        if connection.is_connected():
            connection.close()
    return None

@app.route("/")
def home():
    return render_template("adminLogin.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        user = validate_user(username, password)
        if user:
            session["username"] = username
            flash("Login successful!", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password", "danger")

    return render_template("admin.html")

@app.route("/dashboard")
def dashboard():
    pending = []
    verified = []

    if "username" in session:
        try:
            conn = mysql.connector.connect(**db_config)
            if conn.is_connected():
                cursor = conn.cursor(dictionary=True)

                # Fetch Pending Doctors
                cursor.execute("SELECT * FROM verified_doctors WHERE status ='NOT VERIFIED'")
                pending = cursor.fetchall()

                # Fetch Verified Doctors
                cursor.execute("SELECT * FROM verified_doctors WHERE status ='VERIFIED'")
                verified = cursor.fetchall()

        except Exception as e:
            print(f"Error: {e}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals() and conn.is_connected():
                conn.close()

        # Pass the data to admin.html
        return render_template("admin.html", username=session['username'], pending=pending, verified=verified)
    
    else:
        flash("Please log in to access the dashboard", "warning")
        return redirect(url_for("login"))
    


@app.route("/logout")
def logout():
    session.pop("username", None)
    flash("You have been logged out", "info")
    return redirect(url_for("home"))

@app.route('/send_verification_email/<email>/<first_name>/<last_name>', methods=['GET'])
def send_verification_email(email, first_name, last_name):
    conn = None
    cursor = None

    try:
        # Establish a database connection
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # Update the status of the doctor in the database
        cursor.execute("""
            UPDATE verified_doctors
            SET status = 'VERIFIED'
            WHERE email = %s
        """, (email,))
        conn.commit()  # Commit the changes

        # Send the verification email
        msg = Message("Your Account was Verified",
                      recipients=[email])
        msg.body = f"Congratulations {first_name} {last_name}! Your account has been verified."
        mail.send(msg)  # Send the email

        flash("Verification email sent successfully and status updated to VERIFIED!", "success")
    except Exception as e:
        print(f"Error occurred: {e}")
        flash("Error sending email or updating status. Please try again.", "danger")
    finally:
        # Ensure that the cursor and connection are closed only if they were successfully created
        if cursor:
            cursor.close()
        if conn:
            conn.close()
    
    return redirect(url_for('dashboard'))  # Redirect to your desired page

if __name__ == "__main__":
    app.run(port=5001)
