import requests

class Geocoding:
    def __init__(self, api_key):
        self.api_key = api_key

    def get_coordinates(self, address):
        url = f'https://api.opencagedata.com/geocode/v1/json?q={address}&key={self.api_key}'
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            if data['results']:
                return data['results'][0]['geometry']['lat'], data['results'][0]['geometry']['lng']
        return None
