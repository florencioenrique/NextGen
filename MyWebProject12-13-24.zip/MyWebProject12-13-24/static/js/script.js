document.addEventListener('DOMContentLoaded', function() {
    const submitButton = document.querySelector('#submitButton'); // The submit button in your HTML
    const symptomsInput = document.querySelector('#symptoms_input'); // The input field for symptoms
    const resultContainer = document.querySelector('#freedictionResult'); // The container to display results

    submitButton.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent the default form submission

        const symptoms = symptomsInput.value.split(',').map(symptom => symptom.trim()); // Get symptoms as an array
        
        // Make sure there's input before sending the request
        if (symptoms.length === 0) {
            resultContainer.innerHTML = '<p class="text-danger">Please enter at least one symptom.</p>';
            return;
        }

        fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ symptoms: symptoms })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Clear previous results
            resultContainer.innerHTML = '';

            // Display the expertise for the most likely disease
            const mostLikely = data.most_likely;
            if (mostLikely && mostLikely.expertise) {
                resultContainer.innerHTML += `
                    <div class="card my-3 p-3 shadow-sm">
                        <h5 class="card-title text-primary">Most Likely Disease: ${mostLikely.disease} (${mostLikely.probability.toFixed(2)}%)</h5>
                        <p class="card-text text-muted">Expertise: <span class="text-success">${mostLikely.expertise}</span></p>
                    </div>
                `;
            } else {
                resultContainer.innerHTML += '<p class="text-danger">No predictions available.</p>';
            }

            // Display expertise for top predictions
            const topPredictions = data.top_predictions;
            if (topPredictions.length > 0) {
                resultContainer.innerHTML += '<h5>Other Disease Predictions:</h5><ul class="list-unstyled">';
                topPredictions.forEach(prediction => {
                    if (prediction.expertise) {  // Only display if expertise is available
                        resultContainer.innerHTML += `
                            <div class="card my-3 p-3 shadow-sm">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span>${prediction.disease} (${prediction.probability.toFixed(2)}%)</span>
                                </div>
                                <small class="text-muted">${prediction.expertise}</small>
                            </div>
                        `;
                    }
                });
                resultContainer.innerHTML += '</ul>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            resultContainer.innerHTML = '<p class="text-danger">There was an error processing your request. Please try again.</p>';
        });
    });
});
