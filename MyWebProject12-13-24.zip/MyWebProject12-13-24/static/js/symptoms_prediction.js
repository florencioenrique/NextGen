$(document).ready(function () {
    let selectedGender = '';
    let age = 0;

    // Gender selection handlers
    $('#maleCard').on('click', function () {
        selectedGender = 'Male';
        $('#step2').hide();
        $('#step3').show();
    });

    $('#femaleCard').on('click', function () {
        selectedGender = 'Female';
        $('#step2').hide();
        $('#step3').show();
    });

    // Age input handler
    $('#proceedToSymptoms').on('click', function () {
        age = parseInt($('#age').val().trim());
        if (isNaN(age) || age <= 0 || age > 120) {
            alert('Please enter a valid age between 1 and 120.');
            return;
        }
        $('#step3').hide();
        $('#step4').show();
    });

    // Checkbox-based symptom form submission handler
    $('#symptomForm').on('submit', function (event) {
        event.preventDefault();
        const selectedSymptoms = [];

        // Collect selected symptoms from checkboxes
        $('input[name="symptoms"]:checked').each(function () {
            selectedSymptoms.push($(this).val().trim());
        });

        $('#error-message').text('');

        if (selectedSymptoms.length === 0) {
            $('#error-message').text("Please select at least one symptom.");
            return;
        }

        $.ajax({
            url: '/predict',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ symptoms: selectedSymptoms }),
            success: function (response) {
                $('#most-likely').empty();
                $('#predictions').empty();

                let map;
                let marker;

                // Process most likely disease
                if (response.most_likely) {
                    const mostLikelyProbability = response.most_likely.probability;
                    const mostLikelyDoctors = response.most_likely.doctors || [];

                    $('#most-likely').append(`
                        <li class="list-group-item list-group-item-success p-3 predicted_result mb-3">
                            <h2 class="text-center predicted_disease_title">Predicted Disease</h2>
                            <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between">
                                <div class="mb-3 mb-md-0">
                                    <h5 class="mb-1 disease_name">${response.most_likely.disease} <span class="disease_probability">${mostLikelyProbability.toFixed(2)}%</span></h5>
                                    <p class="mt-2">${response.most_likely.description}</p>
                    
                                </div>
                            </div>
                            <ul id="most-likely-doctors" class="list-group mt-3">
                                ${mostLikelyDoctors.length > 0
                                    ? mostLikelyDoctors.map((doctor) => `
                                        <li class="list-group-item d-flex justify-content-between align-items-center flex-column flex-sm-row p-3 mb-2 doctor_profile">
                                            <div class="d-flex align-items-center mb-3 mb-sm-0 me-3">
                                                <img src="https://cdn-icons-png.flaticon.com/512/149/149071.png"
                                                     alt="Doctor Image"
                                                     class="rounded-circle me-3"
                                                     style="width: 50px; height: 50px;">
                                                <div>
                                                    <strong>${doctor.name}</strong>
                                                    ${doctor.expertise}
                                                    <p class="mb-1 text-muted small">${doctor.address}</p>
                                                </div>
                                            </div>
                                            <button class="btn btn-sm btn-info view-doctor mt-2 mt-sm-0"
                                                    data-doctor-id="${doctor.id}"
                                                    data-doctor-name="${doctor.name}"
                                                    data-doctor-address="${doctor.address}">
                                                View Profile
                                            </button>
                                        </li>
                                    `).join('')
                                    : '<li class="list-group-item text-center">No doctors available</li>'}
                            </ul>
                        </li>
                    `);

                    // Doctor modal and map functionality
                    $('#most-likely-doctors').on('click', '.view-doctor', function () {
                        const doctorId = $(this).data('doctor-id');
                        const doctorName = $(this).data('doctor-name');
                        const doctorAddress = $(this).data('doctor-address');

                        $('#doctorName').text(doctorName);
                        $('#doctorAddress').text(doctorAddress);
                        $('#doctorId').text(doctorId);

                        const doctorModal = new bootstrap.Modal(document.getElementById('doctorModal'));
                        doctorModal.show();

                        const mapContainer = $('#mapContainer');
                        if (!map) {
                            map = L.map(mapContainer[0]).setView([0, 0], 2);
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                maxZoom: 19,
                                attribution: '© OpenStreetMap'
                            }).addTo(map);
                        } else if (marker) {
                            map.removeLayer(marker);
                        }

                        fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(doctorAddress)}`)
                            .then(response => response.json())
                            .then(data => {
                                if (data && data.length > 0) {
                                    const lat = data[0].lat;
                                    const lon = data[0].lon;

                                    map.setView([lat, lon], 13);
                                    marker = L.marker([lat, lon]).addTo(map)
                                        .bindPopup(doctorAddress)
                                        .openPopup();
                                } else {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Oops...',
                                        text: 'Location not found for the given address.',
                                        confirmButtonText: 'Okay'
                                    });
                                }
                            })
                            .catch(error => console.error('Error fetching geolocation:', error));
                    });

                    $('#doctorModal').on('hidden.bs.modal', function () {
                        if (map) {
                            map.remove();
                            map = null;
                        }
                    });
                }

                // Additional predictions
                const mostLikelyDisease = response.most_likely ? response.most_likely.disease : null;
                response.top_predictions.forEach(function (prediction, predictionIndex) {
                    if (prediction.disease !== mostLikelyDisease) {
                        const probability = prediction.probability;
                        const predictionDoctors = prediction.doctors || [];

                        $('#predictions').append(`
                            <li class="list-group-item border rounded mb-3 predicted_result">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h5 class="mb-1 disease_name">${prediction.disease}:<span class="disease_probability">${probability.toFixed(2)}%</span></h5>
                                        <p class="mb-1">${prediction.description}</p>
                                        <small class="text-muted">Doctors:</small>
                                    </div>
                                    <button class="btn btn-info btn-sm ms-2" data-bs-toggle="collapse" data-bs-target="#prediction-doctors-${predictionIndex}" aria-expanded="false" aria-controls="prediction-doctors-${predictionIndex}">
                                        View Doctors
                                    </button>
                                </div>
                                <ul class="list-group collapse mt-2" id="prediction-doctors-${predictionIndex}">
                                    ${predictionDoctors.length > 0
                                        ? predictionDoctors.map((doctor) => `
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                <div>
                                                    <strong>${doctor.name}</strong>
                                                    <br>
                                                    <small>${doctor.address}</small>
                                                </div>
                                                <button class="btn btn-outline-primary btn-sm"
                                                        data-doctor-id="${doctor.id}"
                                                        data-doctor-name="${doctor.name}"
                                                        data-doctor-address="${doctor.address}">
                                                    View Profile
                                                </button>
                                            </li>
                                        `).join('')
                                        : '<li class="list-group-item">No doctors available</li>'}
                                </ul>
                            </li>
                        `);
                    }
                });

                $('#prediction-section').toggle(response.most_likely || response.top_predictions.length > 0);
            },
            error: function (error) {
                $('#predictions').empty();
                $('#error-message').text(error.responseJSON?.error || "An error occurred during prediction.");
            }
        });
    });
});
