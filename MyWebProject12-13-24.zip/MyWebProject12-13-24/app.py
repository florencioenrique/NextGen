from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash
from werkzeug.utils import secure_filename
from flask_mail import Mail, Message
import random
import string
import numpy as np
import pandas as pd
import csv
import os
import mysql.connector
import sqlite3
import uuid
from flask_login import LoginManager, login_user, login_required, logout_user, current_user


vcId = str(uuid.uuid4())

app = Flask(__name__, template_folder='templates')
app.secret_key = 'nextgen2024'

login_manager = LoginManager()
login_manager.init_app(app)

class Doctor:
    def __init__(self, id):
        self.id = id
        self.user_type = 'doctor'

    def get_id(self):
        return self.id
    
class Consultant:
    def __init__(self, id):
        self.id = id
        self.user_type = 'consultant'

    def get_id(self):
        return self.id
    

app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'florencioenrique69@gmail.com'
app.config['MAIL_PASSWORD'] = 'owaw sgni koox vvky'  # Use app password or secure method for real applications
app.config['MAIL_DEFAULT_SENDER'] = 'NextGen Health Diagnostic Web'

mail = Mail(app)


app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# Database connection
def get_db_connection():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='nextgen'
    )
    return connection
    

# Load data from CSV files
data = pd.read_csv('datasets/disease.csv')
data['Symptoms'] = data['Symptoms'].apply(lambda x: x.split(';'))

descriptions = {}
with open('datasets/disease_descriptions.csv', mode='r', newline='') as file:
    reader = csv.DictReader(file)
    for row in reader:
        descriptions[row['Disease']] = row['Description']

doctors = {}
with open('datasets/doctors.csv', mode='r', newline='') as file:
    reader = csv.DictReader(file)
    for row in reader:
        disease = row['Disease']
        doctor_type = row['Doctor_Type']
        if disease not in doctors:
            doctors[disease] = []
        doctors[disease].append(doctor_type)

# def load_symptoms_by_anatomy():
#     symptoms_data = {}
#     with open('datasets/symptoms_anatomy.csv', 'r') as file:
#         reader = csv.DictReader(file)
#         for row in reader:
#             anatomy = row['Anatomy']
#             symptom = row['Symptom']
            
#             if anatomy not in symptoms_data:
#                 symptoms_data[anatomy] = []
            
#             symptoms_data[anatomy].append(symptom)
#     return symptoms_data

def fetch_matched_doctors(disease):
    matched_doctors = []
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT first_name, expertise FROM doctors WHERE expertise = %s", (disease,))
    doctors_data = cursor.fetchall()
    
    for doctor in doctors_data:
        matched_doctors.append(doctor['first_name']) 

    cursor.close()
    conn.close()
    
    return matched_doctors

for disease in doctors.keys():
    matched_doctors = fetch_matched_doctors(disease)
    if matched_doctors:
        doctors[disease] = [{
            'doctor_type': doc['doctor_type'],
            'doctor_name': doc['doctor_na me'],
            'matched_doctors': matched_doctors
        } for doc in doctors[disease]]

from flask import Flask, render_template, request, redirect, url_for, flash
import csv

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/add_disease', methods=['POST'])
def add_disease():
    
    disease = request.form['disease_name']
    symptoms = request.form['symptoms']
    recommended_doctor = request.form['recommended_doctor']
    disease_description = request.form['disease_description']

    if disease and symptoms and recommended_doctor and disease_description:
        symptoms_list = [symptom.strip() for symptom in symptoms.split(';')]

        disease_exists = False
        existing_symptoms = []

        # Update the disease.csv file with new symptoms
        with open('datasets/disease.csv', mode='r', newline='') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0].strip() == disease:
                    disease_exists = True
                    existing_symptoms = row[1].split(';')
                    break

        if disease_exists:
            # Add new symptoms to the existing ones
            existing_symptoms_set = set(existing_symptoms)
            for symptom in symptoms_list:
                existing_symptoms_set.add(symptom)

            symptoms_str = ';'.join(existing_symptoms_set)
            updated_rows = []
            with open('datasets/disease.csv', mode='r', newline='') as file:
                reader = csv.reader(file)
                for row in reader:
                    if row[0].strip() == disease:
                        updated_rows.append([disease, symptoms_str]) 
                    else:
                        updated_rows.append(row)

            with open('datasets/disease.csv', mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerows(updated_rows)

            message = f"Disease '{disease}' updated successfully with new symptoms!"
        else:
            # Add new disease with symptoms to disease.csv
            symptoms_str = ';'.join(symptoms_list)
            with open('datasets/disease.csv', mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([disease, symptoms_str]) 

            message = f"New disease '{disease}' added successfully!"

        # Save the recommended doctor to doctors.csv
        doctor_exists = False
        with open('datasets/doctors.csv', mode='r', newline='') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0].strip() == disease:
                    doctor_exists = True
                    break

        if not doctor_exists:
            with open('datasets/doctors.csv', mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([disease, recommended_doctor])

        # Save the disease description to disease_description.csv
        description_exists = False
        with open('datasets/disease_descriptions.csv', mode='r', newline='') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0].strip() == disease:
                    description_exists = True
                    break

        if not description_exists:
            with open('datasets/disease_descriptions.csv', mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([disease, f'"{disease_description}"'])

        return f"""
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            Swal.fire({{
                title: 'Success!',
                text: '{message}',
                icon: 'success',
                confirmButtonText: 'OK'
            }}).then(() => {{
                window.location.href = '{url_for('experts_dashboard')}';
            }});
        </script>
        """
    else:
        return f"""
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            Swal.fire({{
                title: 'Error!',
                text: 'Please provide disease name, symptoms, recommended doctor, and description.',
                icon: 'error',
                confirmButtonText: 'OK'
            }}).then(() => {{
                window.history.back();
            }});
        </script>
        """

# Prepare symptom and disease lists
symptoms = list(set([symptom for sublist in data['Symptoms'] for symptom in sublist]))
diseases = data['Disease'].unique()

X = np.array([[1 if symptom in symptoms_list else 0 for symptom in symptoms] for symptoms_list in data['Symptoms']])
y = np.array([[1 if d == disease else 0 for d in diseases] for disease in data['Disease']])

class SimpleNN:
    def __init__(self, input_size, hidden_size, output_size):
        self.W1 = np.random.rand(input_size, hidden_size)
        self.W2 = np.random.rand(hidden_size, output_size)

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_derivative(self, x):
        return x * (1 - x)

    def feedforward(self, X):
        self.hidden = self.sigmoid(np.dot(X, self.W1))
        self.output = self.sigmoid(np.dot(self.hidden, self.W2))
        return self.output

    def backpropagation(self, X, y, learning_rate):
        output_error = y - self.output
        output_delta = output_error * self.sigmoid_derivative(self.output)

        hidden_error = output_delta.dot(self.W2.T)
        hidden_delta = hidden_error * self.sigmoid_derivative(self.hidden)

        self.W2 += self.hidden.T.dot(output_delta) * learning_rate
        self.W1 += X.T.dot(hidden_delta) * learning_rate

    def train(self, X, y, epochs, learning_rate):
        for _ in range(epochs):
            self.feedforward(X)
            self.backpropagation(X, y, learning_rate)

nn = SimpleNN(len(symptoms), 5, len(diseases))
nn.train(X, y, epochs=10000, learning_rate=0.1)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/userReg')
def user_registration():
    return render_template('userReg.html')

@app.route('/symptomsChecker')
def symptoms_checker():
    return render_template('symptomsChecker.html', symptoms=symptoms)

@app.route('/about')
def view_about():
    return render_template('about.html')

@app.route('/vc/<vcId>')
def vc(vcId):

    if 'user_fname' not in session or 'user_lname' not in session:
        return redirect(url_for('home'))
    
    patient_fname = session['user_fname']
    patient_lname = session['user_lname']

    expert_name = session['expert_name']

    doctor_fname = session.get('expert_fname', None)
    doctor_lname = session.get('expert_lname', None)

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute('''
        SELECT * FROM appointment WHERE vcId = %s
    ''', (vcId,))

    appointment = cursor.fetchone()
    
    cursor.close()
    conn.close()

    if appointment:
        return render_template('vc.html', appointment=appointment, patient_fname=patient_fname, patient_lname=patient_lname,  doctor_fname=doctor_fname, doctor_lname=doctor_lname, expert_name = expert_name)
    else:
        return "Appointment not found", 404

@app.route('/join/<vcId>')
def join(vcId):

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    patient_name = session['user_fname']
    patient_lname = session['user_lname']
    
    cursor.execute("SELECT * FROM appointment WHERE vcId = %s", (vcId,))
    appointment = cursor.fetchone()

    if not appointment:
        cursor.close()
        conn.close()
        return "Appointment not found.", 404

    cursor.execute("UPDATE appointment SET report = 'Done' WHERE vcId = %s", (vcId,))

    conn.commit()

    cursor.close()
    conn.close()

    return render_template('vc.html', vcId=vcId, appointment=appointment,  patient_name=  patient_name, patient_lname= patient_lname)


@app.route('/contact')
def view_contact():
    return render_template('contact.html')

@app.route('/registration_form', methods=['GET', 'POST'])
def registration_form():
    if request.method == 'POST':
        user_type = request.form['userType']
        first_name = request.form['firstName']
        last_name = request.form['lastName']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        zip_code = request.form['zipCode']
        username = request.form['username']
        password = request.form['password']
        status = request.form['status']
        date = request.form['dateCreated']

        medical_license = request.form.get('medicalLicense', '')
        specialization = request.form.get('specialization', '')

        # Handle file upload
        certificate_path = None
        if 'certificate' in request.files:
            certificate_file = request.files['certificate']
            if certificate_file.filename != '':
                filename = secure_filename(certificate_file.filename)
                certificate_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                certificate_file.save(certificate_path)

        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            if user_type == 'consultant':
                cursor.execute('''
                    INSERT INTO consultanttable (first_name, last_name, email, phone, address, zip_code, username, password, certificate_path)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                ''', (first_name, last_name, email, phone, address, zip_code, username, password, certificate_path))
            elif user_type == 'doctor':
                cursor.execute('''
                    INSERT INTO doctors (first_name, last_name, email, phone, address, zip_code, username, password, 
                    medLicense, expertise, date, status, certificate_path)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ''', (first_name, last_name, email, phone, address, zip_code, username, password,
                    medical_license, specialization, date, status, certificate_path))

            conn.commit()
            flash('success', 'Registration successful!')
            return redirect(url_for('home'))  # Redirect to a success page after registration

        except Exception as e:
            print(f"Error occurred: {e}")
            flash('danger', 'Registration failed. Please try again.')
            return redirect(url_for('home'))

        # finally:
        #     cursor.close()
        #     conn.close()

    return render_template('home.html')

@app.route('/submit_appointment', methods=['POST'])
def submit_appointment():
    if 'user_id' not in session:
        return redirect(url_for('home'))
    
    patient_id = session['user_id']
    patient_name = session['user_fname']
    
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''
        SELECT email FROM consultanttable WHERE id = %s AND first_name = %s
    ''', (patient_id, patient_name))

    result = cursor.fetchone()
    
    if result:
        patient_email = result[0]
    else:
        patient_email = None

    aptype = request.form['aptype']
    date = request.form['date']
    status = 'Pending'
    report = 'Ongoing'
    doctorId = request.form['doctorId']

    vcId = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

    cursor.execute('''
        INSERT INTO appointment (type, appointment_date, status, patientId, doctorId, name, email, vcId, report)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    ''', (aptype, date, status, patient_id, doctorId, patient_name, patient_email, vcId, report))

    conn.commit()
    cursor.close()
    conn.close()

    return redirect(url_for('consultant', success=True))

@app.route('/success_page')
def success_page():
    return render_template('userReg.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    symptoms_input = [symptom.capitalize() for symptom in data['symptoms']]

    not_found_symptoms = [symptom for symptom in symptoms_input if symptom not in symptoms]
    if not_found_symptoms:
        return jsonify({'error': f"Symptoms not found: {', '.join(not_found_symptoms)}"}), 400

    sample_input = np.array([[1 if symptom in symptoms_input else 0 for symptom in symptoms]])
    output = nn.feedforward(sample_input)

    predictions = {disease: output[0][i] for i, disease in enumerate(diseases)}
    sorted_predictions = sorted(predictions.items(), key=lambda item: item[1], reverse=True)

    top_predictions = [
        {
            'disease': sorted_predictions[i][0],
            'probability': sorted_predictions[i][1] * 100,
            'description': descriptions.get(sorted_predictions[i][0], ''),
            'doctors': [],
            'expertise': ''
        } 
        for i in range(min(5, len(sorted_predictions)))
    ]

    most_likely = top_predictions[0] if top_predictions else {}

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Match doctors based on disease
    if most_likely:
        disease = most_likely['disease']
        doctor_types = doctors.get(disease, [])

        for doctor_type in doctor_types:
            cursor.execute("SELECT id, first_name, last_name, address, expertise FROM doctors WHERE expertise = %s", (doctor_type,))
            matched_doctors = cursor.fetchall()
            for doc in matched_doctors:
                most_likely['doctors'].append({
                    'id': doc['id'],
                    'name': f"{doc['first_name']} {doc['last_name']}",
                    'address': doc['address'],                   
                })
                most_likely['expertise'] = doc['expertise']

    for i in range(len(top_predictions)):
        disease = top_predictions[i]['disease']
        doctor_types = doctors.get(disease, [])
        expertise_set = set()
        doctors_list = []

        for doctor_type in doctor_types:
            cursor.execute("SELECT id, first_name, last_name, address, expertise FROM doctors WHERE expertise = %s", (doctor_type,))
            matched_doctors = cursor.fetchall()
            for doc in matched_doctors:
                expertise_set.add(doc['expertise'])
                doctors_list.append({
                    'id': doc['id'],
                    'name': f"{doc['first_name']} {doc['last_name']}",
                    'address': doc['address'],
                    'expertise': doc['expertise']
                })

        top_predictions[i]['expertise'] = ', '.join(expertise_set)
        top_predictions[i]['doctors'] = doctors_list

    cursor.close()
    conn.close()

    return jsonify({
        'most_likely': most_likely,
        'top_predictions': top_predictions
    })


@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)  # Using dictionary cursor
    cursor.execute("SELECT * FROM consultanttable WHERE username = %s AND password = %s", (username, password))
    user = cursor.fetchone()
    connection.close()

    if user:
        # Store user id, first name, and last name in session
        session['user_id'] = user['id']
        session['user_fname'] = user['first_name']
        session['user_lname'] = user['last_name']

        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': 'Incorrect username or password!'})
 
@app.route('/expert_login', methods=['POST'])
def expert_login():
    username = request.form['username']
    password = request.form['password']

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM doctors WHERE username = %s AND password = %s", (username, password))
    expert = cursor.fetchone()
    connection.close()

    if expert:
        session['expert_id'] = expert['id']
        session['expert_name'] = f"{expert['first_name']} {expert['last_name']}"
        session['expert_username'] = expert['username']
        print("Expert Name in Session:", session['expert_name'])  # Debug statement
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': 'Incorrect username or password!'})
    
@login_manager.user_loader
def load_user(user_id):
    # Logic to load the user based on the session data
    if session.get('user_type') == 'doctor':
        return Doctor(user_id)
    elif session.get('user_type') == 'consultant':
        return Consultant(user_id)
    return None

@app.route('/consultant')
def consultant():
    # data = load_symptoms_by_anatomy()

    if 'user_id' not in session:
        return redirect(url_for('home'))
    
      
    user_fname = session.get('user_fname', "User")
    user_lname = session.get('user_lname', "User")
    user_email = session.get('user_email', "User")
    user_id = session['user_id']
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT DISTINCT expertise FROM doctors")
    expertise_list = [row['expertise'] for row in cursor.fetchall()]

    cursor.execute("SELECT * FROM doctors")
    doctor = cursor.fetchall()

    cursor.execute('''
        SELECT *
        FROM consultanttable
        WHERE id = %s
    ''', (user_id,))
    user_data = cursor.fetchone()

    if not user_data:
        return redirect(url_for('home'))

    first_name = user_data['first_name']
    last_name = user_data['last_name']
    email = user_data['email']
    phone = user_data['phone']
    address = user_data['address']

    cursor.execute("""
        SELECT doctors.id, doctors.first_name, doctors.last_name, doctors.expertise AS type, doctors.address,
               appointment.appointment_date, appointment.vcId, appointment.type
        FROM doctors
        JOIN appointment ON doctors.id = appointment.doctorId
        WHERE appointment.patientId = %s AND appointment.status = 'Accepted' AND appointment.report = 'Ongoing'
    """, (session['user_id'],))
    
    appointed_doctors = cursor.fetchall()

    cursor.close()
    conn.close()
    success = request.args.get('success', False)
    return render_template('consultant.html', symptoms=symptoms, expertise_list=expertise_list, doctor=doctor, appointed_doctors=appointed_doctors, user_fname=user_fname, data=data, success=success,  user_lname =  user_lname, user_email= user_email, first_name = first_name, last_name = last_name, email = email, phone = phone, address = address)

@app.route('/update_personal_info', methods=['POST'])
def update_personal_info():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect to login if user is not logged in

    user_id = session['user_id']  # Get user_id from session

    if request.method == 'POST':
        # Get the form data
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']

        # Connect to the database
        conn = get_db_connection()
        cursor = conn.cursor()

        # SQL query to update personal information in the consultanttable
        update_query = """
            UPDATE consultanttable
            SET first_name = %s, last_name = %s, email = %s, phone = %s, address = %s
            WHERE id = %s
        """

        # Execute the query with the provided data
        cursor.execute(update_query, (first_name, last_name, email, phone, address, user_id))

        return redirect(url_for('consultant'))

# Expert dashboard route
@app.route('/experts_dashboard')
def experts_dashboard():
    if 'expert_id' not in session:
        return redirect(url_for('home'))

    # Get the expert's ID from the session
    expert_id = session['expert_id']

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch the expert's expertise based on their expert_id
    cursor.execute('''
        SELECT *
        FROM doctors
        WHERE id = %s
    ''', (expert_id,))
    expert_data = cursor.fetchone()


    if not expert_data:
        return redirect(url_for('home'))

    expert_expertise = expert_data['expertise']
    expert_status = expert_data['status']

    # Get the expert's full name from session (This should contain "FirstName LastName")
    expert_name = session.get('expert_name', '')

    # Fetch additional data related to the patient (if needed)
    patient_fname = session.get('user_fname', '')
    patient_lname = session.get('user_lname', '')

    # Fetch consultants (doctors)
    cursor.execute("SELECT first_name, last_name, email FROM consultanttable")
    consultants = cursor.fetchall()

    # Fetch pending appointments
    cursor.execute('''
        SELECT appointment.id, appointment.type, appointment.appointment_date, appointment.status,
               consultanttable.first_name, consultanttable.last_name, consultanttable.email
        FROM appointment
        JOIN consultanttable ON appointment.patientId = consultanttable.id
        WHERE appointment.doctorId = %s
        AND consultanttable.first_name = %s
        AND consultanttable.last_name = %s
        AND appointment.status = 'Pending'
    ''', (expert_id, patient_fname, patient_lname))
    appointments = cursor.fetchall()

    # Fetch accepted appointments
    cursor.execute('''
        SELECT appointment.id, appointment.type, appointment.appointment_date, appointment.status,
               consultanttable.first_name, consultanttable.last_name, consultanttable.email, appointment.vcId
        FROM appointment
        JOIN consultanttable ON appointment.patientId = consultanttable.id
        WHERE appointment.doctorId = %s
        AND consultanttable.first_name = %s
        AND consultanttable.last_name = %s
        AND appointment.status = 'Accepted'
    ''', (expert_id, patient_fname, patient_lname))
    accepted_appointments = cursor.fetchall()

    cursor.close()
    conn.close()

    # Pass expert_name, expert_expertise, and other data to the template
    return render_template(
        'experts.html',
        expert_name=expert_name,
        expert_expertise=expert_expertise,  # Pass the expertise to the template
        consultants=consultants,
        appointments=appointments,
        accepted_appointments=accepted_appointments,
        symptoms=symptoms,  # Ensure 'symptoms' is defined elsewhere in your code
        expert_status = expert_status,
    )


@app.route('/accept/<int:appointment_id>', methods=['POST'])
def accept_appointment(appointment_id):
    # Get the email, first name, and appointment date from the request form or query params
    email = request.form.get('email') or request.args.get('email')
    first_name = request.form.get('first_name') or request.args.get('first_name')
    appointment_date = request.form.get('appointment_date') or request.args.get('appointment_date')

    if email and first_name and appointment_date:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get appointment details to use for the email
        cursor.execute("SELECT email, name, appointment_date FROM appointment WHERE id = %s", (appointment_id,))
        appointment = cursor.fetchone()

        if appointment:
            cursor.execute("UPDATE appointment SET status = 'Accepted' WHERE id = %s", (appointment_id,))
            conn.commit()
            conn.close()

            return redirect(url_for('experts_dashboard'))
        else:
            conn.close()
            return "Appointment not found."

    return "Required information is missing."

# Example function to send an acceptance email
def send_acceptance_email(email, first_name, appointment_date):
    subject = "Appointment Accepted"
    body = f"Dear {first_name},\n\nYour appointment on {appointment_date} has been accepted.\n\nBest regards,\nNextGen Health Diagnostic Web"
    
    msg = Message(subject=subject, recipients=[email], body=body)
    
    try:
        mail.send(msg)
        print("Email sent successfully!")
    except Exception as e:
        print(f"Failed to send email: {e}")

@app.route('/logout')
def logout():
    # Clear session data based on user type
    if 'consultant_id' in session:
        session.pop('consultant_id', None)
        session.pop('consultant_fname', None)
        session.pop('consultant_lname', None)
    elif 'expert_id' in session:
        session.pop('expert_id', None)
        session.pop('expert_name', None)
        session.pop('expert_username', None)

    # Redirect to home page or login page
    return redirect(url_for('home'))


if __name__ == '__main__':
    app.secret_key = 'nextGenHD 2024'
    app.run(host='0.0.0.0', port=5000)  
    app.run(debug=True)