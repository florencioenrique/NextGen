import mysql.connector

def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='nextgen'
    )

class UserModel:
    def register_user(self, form_data):
        user_type = form_data['userType']
        first_name = form_data['firstName']
        last_name = form_data['lastName']
        email = form_data['email']
        phone = form_data['phone']
        address = form_data['address']
        username = form_data['username']
        password = form_data['password']

        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            if user_type == 'consultant':
                cursor.execute('''INSERT INTO consultanttable (first_name, last_name, email, phone, address, username, password)
                                  VALUES (%s, %s, %s, %s, %s, %s, %s)''', 
                               (first_name, last_name, email, phone, address, username, password))
            elif user_type == 'doctor':
                # Add additional fields for doctors
                pass  # Code similar to consultant

            conn.commit()
            return True
        except:
            conn.rollback()
            return False
        finally:
            cursor.close()
            conn.close()

    def login_consultant(self, username, password):
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM consultanttable WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        return user

    def login_expert(self, username, password):
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM expertstable WHERE username = %s AND password = %s", (username, password))
        expert = cursor.fetchone()
        cursor.close()
        conn.close()
        return expert

    def get_doctors(self):
        # Fetch all registered doctors
        pass

    def get_consultants(self):
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT first_name FROM consultanttable")
        consultants = cursor.fetchall()
        cursor.close()
        conn.close()
        return consultants
