$(document).ready(function() {
    let selectedGender = '';
    let age = 0;

    // Gender selection handlers
    $('#maleCard').on('click', function() {
        selectedGender = 'Male';
        $('#step2').hide();
        $('#step3').show();
    });

    $('#femaleCard').on('click', function() {
        selectedGender = 'Female';
        $('#step2').hide();
        $('#step3').show();
    });

    // Age input handler
    $('#proceedToSymptoms').on('click', function() {
        age = parseInt($('#age').val().trim());
        if (isNaN(age) || age <= 0 || age > 120) {
            alert('Please enter a valid age between 1 and 120.');
            return;
        }
        $('#step3').hide();
        $('#step4').show();
    });

    $(document).ready(function() {
        $('#symptomForm').on('submit', function(event) {
            event.preventDefault();
            const symptomsInput = $('#symptoms').val().trim();
            $('#error-message').text('');

            if (symptomsInput === '') {
                $('#error-message').text("Please input symptoms.");
                return;
            }

            const symptoms = symptomsInput.split(',').map(symptom => symptom.trim());

            $.ajax({
                url: '/predict',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ symptoms }),
                success: function(response) {

                    $('#most-likely').empty();
                    $('#predictions').empty();

                    
                    let map;
                    let marker;

                    if (response.most_likely) {
                        const mostLikelyProbability = response.most_likely.probability;
                        const mostLikelyDoctors = response.most_likely.doctors && response.most_likely.doctors.length > 0 
                            ? response.most_likely.doctors 
                            : [];

                            $('#most-likely').append(`
                                <li class="list-group-item list-group-item-success p-3">
                                    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between">
                                        <!-- Disease Information -->
                                        <div class="mb-3 mb-md-0">
                                            <h5 class="mb-1">${response.most_likely.disease}</h5>
                                            <span class="badge bg-primary">${mostLikelyProbability.toFixed(2)}%</span>
                                            <p class="mt-2">${response.most_likely.description}</p>
                                            <p class="mt-2"><strong>Age:</strong> ${age} years</p>
                                            <p class="mt-2"><strong>Gender:</strong> ${selectedGender}</p>
                                        </div>
                                        
                                        <!-- Recommended Doctors Header -->
                                        <div class="text-md-end mt-3 mt-md-0">
                                            <small class="text-muted d-block">Recommended Doctors:</small>
                                        </div>
                                    </div>
                                    
                                    <!-- Doctors List -->
                                    <ul id="most-likely-doctors" class="list-group mt-3">
                                        ${mostLikelyDoctors.length > 0 
                                            ? mostLikelyDoctors.map((doctor) => `
                                                <li class="list-group-item d-flex justify-content-between align-items-center flex-column flex-sm-row p-3">
                                                    <!-- Doctor Image -->
                                                    <div class="d-flex align-items-center mb-3 mb-sm-0 me-3">
                                                        <img src="https://cdn-icons-png.flaticon.com/512/149/149071.png" 
                                                            alt="Doctor Image" 
                                                            class="rounded-circle me-3"
                                                            style="width: 50px; height: 50px;">
                                                        <!-- Doctor Info -->
                                                        <div>
                                                            <strong>${doctor.name}</strong>
                                                            <p class="mb-1 text-muted small">${doctor.address}</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <!-- View Profile Button -->
                                                    <button class="btn btn-sm btn-info view-doctor mt-2 mt-sm-0" 
                                                            data-doctor-id="${doctor.id}" 
                                                            data-doctor-name="${doctor.name}" 
                                                            data-doctor-address="${doctor.address}">
                                                        View Profile
                                                    </button>
                                                </li>
                                                
                                            `).join('') 
                                            : '<li class="list-group-item text-center">No doctors available</li>'
                                        }
                                    </ul>
                                </li>
                            `);
                            

                        $('#most-likely-doctors').on('click', '.view-doctor', function() {
                            const doctorId = $(this).data('doctor-id');
                            const doctorName = $(this).data('doctor-name');
                            const doctorAddress = $(this).data('doctor-address');

                            // Set the modal content
                            $('#doctorName').text(doctorName);
                            $('#doctorAddress').text(doctorAddress);

                            $('#doctorId').text(doctorId);
                            
                            // Show the modal
                            const doctorModal = new bootstrap.Modal(document.getElementById('doctorModal'));
                            doctorModal.show();

                            // Initialize or reset the map
                            const mapContainer = $('#mapContainer');
                            if (!map) {
                                // Create map only if it hasn't been initialized
                                map = L.map(mapContainer[0]).setView([0, 0], 2);
                                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                    maxZoom: 19,
                                    attribution: '© OpenStreetMap'
                                }).addTo(map);
                            } else {
                                // Clear previous marker if exists
                                if (marker) {
                                    map.removeLayer(marker);
                                }
                            }

                            // Fetch the doctor's geolocation
                            fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(doctorAddress)}`)
                            .then(response => response.json())
                            .then(data => {
                                if (data && data.length > 0) {
                                    const lat = data[0].lat;
                                    const lon = data[0].lon;

                                    // Update map view and add marker
                                    map.setView([lat, lon], 13);
                                    marker = L.marker([lat, lon]).addTo(map)
                                        .bindPopup(doctorAddress)
                                        .openPopup();
                                } else {
                                    alert('Location not found for the given address.');
                                }
                            })
                            .catch(error => {
                                console.error('Error fetching geolocation:', error);
                            });
                        });

                        // Remove map data when modal is hidden to reset for the next doctor
                        $('#doctorModal').on('hidden.bs.modal', function () {
                            if (map) {
                                map.remove();
                                map = null;
                            }
                        });
                    }

                    
                    const mostLikelyDisease = response.most_likely ? response.most_likely.disease : null;
                    response.top_predictions.forEach(function(prediction, predictionIndex) {
                        if (prediction.disease !== mostLikelyDisease) {
                            const probability = prediction.probability;
                                    
                            const predictionDoctors = prediction.doctors && prediction.doctors.length > 0 
                            ? prediction.doctors 
                            : [];

                            $('#predictions').append(`
                                <li class="list-group-item border rounded mb-3">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h5 class="mb-1">${prediction.disease}:</h5>
                                            <span class="badge bg-success">${probability.toFixed(2)}%</span>
                                            <p class="mb-1">${prediction.description}</p>
                                            <small class="text-muted">Doctors:</small>
                                        </div>
                                        <button class="btn btn-info btn-sm ms-2" data-bs-toggle="collapse" data-bs-target="#prediction-doctors-${predictionIndex}" aria-expanded="false" aria-controls="prediction-doctors-${predictionIndex}">
                                            View Doctors
                                        </button>
                                    </div>
                                    <ul class="list-group collapse mt-2" id="prediction-doctors-${predictionIndex}">
                                        ${predictionDoctors.length > 0 
                                            ? predictionDoctors.map((doctor) => `
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <strong>${doctor.name}</strong>
                                                        <br>
                                                        <small>${doctor.address}</small>
                                                    </div>
                                                    <button class="btn btn-outline-primary btn-sm" 
                                                            data-doctor-id="${doctor.id}" 
                                                            data-doctor-name="${doctor.name}" 
                                                            data-doctor-address="${doctor.address}">
                                                        View Profile
                                                    </button>
                                                </li>
                                                `).join('') 
                                            : '<li class="list-group-item">No doctors available</li>'
                                        }
                                    </ul>
                                </li>
                            `);
                            
                            
                        }
                    });

                    if (response.most_likely || response.top_predictions.length > 0) {
                        $('#prediction-section').show();
                    } else {
                        $('#prediction-section').hide(); // Hide if no predictions
                    }
                },
                error: function(error) {
                    $('#predictions').empty();

                    if (error.responseJSON && error.responseJSON.error) {
                        $('#error-message').text(error.responseJSON.error);
                    } else {
                        $('#error-message').text("An error occurred during prediction.");
                    }
                }
            });
        });
    });
});
